import { Link } from "react-router";
import { TopicSelect } from "../ui";
import { contactHref } from "../../data/site";

export default function EitlContact() {
  return (
    <section className="bg-primary text-primary-ink">
      <div className="page-wrap grid-12 items-center gap-y-8 py-14 lg:py-16">
        <h2 className="section-title max-w-[28rem] text-primary-ink lg:col-span-5">
          Bring an accountable human into the conversation.
        </h2>
        <div className="lg:col-span-6 lg:col-start-7">
          <TopicSelect ids={["partnerships", "legal", "general"]} defaultTopic="partnerships" light />
          <p className="mt-4 text-[15px] text-primary-ink/90">
            Legal questions have their own route:{" "}
            <Link to={contactHref("legal")} className="font-medium underline underline-offset-4 hover:no-underline">
              write to Legal
            </Link>
            .
          </p>
        </div>
      </div>
    </section>
  );
}
