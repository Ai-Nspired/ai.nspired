import { FileText, Brain, UserRound, ArrowDown } from "lucide-react";
import { Reveal, Stagger, StaggerItem, cn } from "@wron/kit";
import { Status, Button } from "../ui";

const STEPS = [
  { icon: FileText, title: "Source material", body: "Documents, data and context", tone: "bg-bg border-line text-ink" },
  { icon: Brain, title: "AI reasoning", body: "Analyzes, connects and proposes", tone: "bg-bg border-line text-ink" },
  { icon: UserRound, title: "Expert review", body: "Validates, edits and challenges", tone: "bg-accent/20 border-accent/40 text-ink" },
  { icon: UserRound, title: "Human accountable", body: "Makes the decision", tone: "bg-primary border-primary text-primary-ink" },
];

export default function EitlHero() {
  return (
    <section className="border-b border-line">
      <div className="page-wrap grid h-auto grid-cols-1 items-center gap-y-0 overflow-visible py-10 lg:grid-cols-12 lg:gap-x-6 lg:py-[38px]">
        <div className="lg:col-span-5">
          <Reveal>
            <Status label="EITL Governance Framework" state="Active" />
            <h1 className="inner-title mt-8 text-[42px] leading-none lg:text-[clamp(40px,4.2vw,64px)] lg:leading-[1.03]">Expert-in-the-Loop</h1>
            <p className="mt-6 max-w-[30rem] text-[clamp(20px,1.9vw,26px)] leading-[1.4] text-muted">
              A governance framework that keeps humans accountable where AI decisions matter.
            </p>
            <Button to="/contact?topic=partnerships#message" className="mt-8">
              Ask about EITL
            </Button>
          </Reveal>
        </div>
        <div className="mt-8 w-full max-w-none lg:col-span-6 lg:col-start-7 lg:mt-0">
          <Stagger gap={0.07} className="w-full rounded-[4px] bg-surface p-5 sm:p-10">
            {STEPS.map((s, i) => (
              <StaggerItem key={s.title}>
                <div className={cn("flex items-center gap-5 rounded-[4px] border px-5 py-4", s.tone)}>
                  <s.icon className="h-8 w-8 shrink-0" aria-hidden />
                  <div>
                    <p className="text-[17px] font-medium leading-tight">{s.title}</p>
                    <p className={cn("mt-1 text-[14px]", i === 3 ? "text-primary-ink/85" : "text-muted")}>{s.body}</p>
                  </div>
                </div>
                {i < STEPS.length - 1 && (
                  <div className="flex justify-center py-2 text-ink" aria-hidden>
                    <ArrowDown className="h-6 w-6" />
                  </div>
                )}
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </div>
    </section>
  );
}
