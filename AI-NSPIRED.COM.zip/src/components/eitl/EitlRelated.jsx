import { Reveal } from "@wron/kit";
import { SectionHeading, TextLink } from "../ui";

export default function EitlRelated() {
  return (
    <section className="border-b border-line">
      <div className="page-wrap py-16 lg:py-20">
        <SectionHeading title="Related systems" intro="EITL works with other parts of the platform." />
        <div className="grid-12 mt-10 gap-y-6">
          <Reveal className="lg:col-span-7">
            <article className="h-full border border-line bg-bg p-7 transition-shadow hover:shadow-[inset_3px_0_0_#0F6B4F] lg:p-9">
              <p className="text-[15px] text-muted">Methodology</p>
              <h3 className="mt-3 text-[28px] font-semibold leading-tight">Truth Engine</h3>
              <p className="mt-3 max-w-[28rem] text-[18px] text-muted">Make reasoning visible, testable and editable.</p>
              <TextLink to="/truth-engine" arrow className="mt-6">Explore Truth Engine</TextLink>
            </article>
          </Reveal>
          <Reveal delay={0.07} className="lg:col-span-5">
            <article className="h-full border border-line bg-bg p-7 transition-shadow hover:shadow-[inset_3px_0_0_#0F6B4F] lg:p-9">
              <p className="text-[15px] text-muted">Peer review</p>
              <h3 className="mt-3 text-[28px] font-semibold leading-tight">Speakeasy</h3>
              <p className="mt-3 text-[18px] text-muted">A private, vetted network for people building real systems, not hype.</p>
              <TextLink to="/speakeasy" arrow className="mt-6">Visit the Speakeasy</TextLink>
            </article>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
