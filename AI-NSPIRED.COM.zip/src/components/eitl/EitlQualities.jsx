import { SectionHeading } from "../ui";

const ROWS = [
  ["Visible reasoning", "Sources, claims and contradictions remain inspectable.", "Humans and experts, with AI as an assistant."],
  ["Expert editability", "Human expertise can challenge and revise the reasoning.", "Qualified experts, with humans in the loop."],
  ["Human accountability", "AI does not replace responsibility where decisions matter.", "Humans, with expert support when needed."],
];
const HEAD = ["Quality", "What remains visible", "Who stays responsible"];

export default function EitlQualities() {
  return (
    <section className="border-b border-line bg-surface">
      <div className="page-wrap py-16 lg:py-20">
        <SectionHeading title="Governance qualities" intro="The principles that keep EITL accountable and effective." />
        <div className="mt-10 hidden border border-line bg-bg md:block">
          <table className="w-full border-collapse text-left">
            <thead>
              <tr className="bg-surface">
                {HEAD.map((h) => (
                  <th key={h} scope="col" className="border-b border-line px-7 py-5 text-[16px] font-medium">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ROWS.map((r) => (
                <tr key={r[0]} className="group border-b border-line last:border-0 hover:shadow-[inset_3px_0_0_#0F6B4F]">
                  <th scope="row" className="w-[28%] px-7 py-9 align-top text-[17px] font-medium">{r[0]}</th>
                  <td className="w-[36%] border-l border-line px-7 py-9 align-top text-[17px] text-muted">{r[1]}</td>
                  <td className="border-l border-line px-7 py-9 align-top text-[17px] text-muted">{r[2]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <ul className="mt-8 space-y-4 md:hidden">
          {ROWS.map((r) => (
            <li key={r[0]} className="border border-line border-l-[3px] border-l-primary bg-bg p-5">
              <p className="text-[18px] font-medium">{r[0]}</p>
              <p className="mt-3 text-[14px] font-medium">{HEAD[1]}</p>
              <p className="compact text-muted">{r[1]}</p>
              <p className="mt-3 text-[14px] font-medium">{HEAD[2]}</p>
              <p className="compact text-muted">{r[2]}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
