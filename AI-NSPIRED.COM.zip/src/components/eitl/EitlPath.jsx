import { Reveal, cn } from "@wron/kit";
import { SectionHeading } from "../ui";

const ITEMS = [
  { n: "01", title: "Source material stays visible", body: "Original sources, data and context remain accessible and traceable." },
  { n: "02", title: "Claims can be tested", body: "Assertions and reasoning can be checked against the source material." },
  { n: "03", title: "Experts can review and edit reasoning", body: "Qualified experts can challenge, refine and add context to the AI's reasoning." },
  { n: "04", title: "Humans remain accountable for decisions", body: "Final decisions and outcomes stay with human beings where it matters." },
];

export default function EitlPath() {
  return (
    <section className="border-b border-line">
      <div className="page-wrap py-16 lg:py-20">
        <SectionHeading title="The accountability path" intro="From information to decision, with human oversight at every step." />
        <ol className="relative mt-12 lg:mt-14">
          <span className="absolute bottom-0 left-[14px] top-0 w-px bg-primary/70 lg:left-1/2" aria-hidden />
          {ITEMS.map((it, i) => {
            const right = i % 2 === 1;
            return (
              <li key={it.n} className="relative pb-12 pl-12 last:pb-0 lg:grid lg:grid-cols-2 lg:gap-0 lg:pb-20 lg:pl-0">
                <span className="absolute left-[10px] top-4 h-[9px] w-[9px] rounded-full bg-ink lg:left-1/2 lg:-ml-1" aria-hidden />
                <Reveal className={cn("flex items-start gap-6 lg:gap-8", right ? "lg:col-start-2 lg:pl-14" : "lg:justify-end lg:pr-14")}>
                  <span className="tnum text-[56px] font-medium leading-none tracking-[-0.04em] text-primary lg:text-[72px]">{it.n}</span>
                  <div className="max-w-[22rem] pt-1">
                    <h3 className="text-[20px] font-medium leading-[1.25] tracking-[-0.02em]">{it.title}</h3>
                    <p className="compact mt-2 text-muted">{it.body}</p>
                  </div>
                </Reveal>
              </li>
            );
          })}
        </ol>
      </div>
    </section>
  );
}
