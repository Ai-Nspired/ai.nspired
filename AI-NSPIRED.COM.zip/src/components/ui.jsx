import { Link, useNavigate } from "react-router";
import { useState } from "react";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { cn, storage } from "@wron/kit";
import { TOPICS, contactHref } from "../data/site";

/* Buttons ------------------------------------------------------------ */

const base =
  "inline-flex min-h-[48px] items-center justify-center gap-2 rounded-[4px] px-6 text-[16px] font-medium transition-colors duration-150 active:scale-[0.98]";

export const btnPrimary = cn(base, "bg-primary text-primary-ink hover:bg-[#0B5540]");
export const btnOutline = cn(base, "border border-ink/25 bg-bg text-ink hover:border-primary hover:text-primary");
export const btnOnDark = cn(base, "bg-bg text-ink hover:bg-surface");

/** Internal or external button. `variant`: primary | outline | onDark */
export function Button({ to, href, variant = "primary", className, children, ...rest }) {
  const cls = cn(variant === "outline" ? btnOutline : variant === "onDark" ? btnOnDark : btnPrimary, className);
  if (href)
    return (
      <a href={href} target="_blank" rel="noreferrer" className={cls} {...rest}>
        {children}
      </a>
    );
  if (to)
    return (
      <Link to={to} className={cls} {...rest}>
        {children}
      </Link>
    );
  return (
    <button type="button" className={cls} {...rest}>
      {children}
    </button>
  );
}

/** Underlined green text link, with an optional arrow. */
export function TextLink({ to, href, className, children, arrow = false, external }) {
  const cls = cn(
    "group inline-flex min-h-[44px] items-center gap-1.5 text-[16px] font-medium text-primary underline decoration-1 underline-offset-[5px] hover:decoration-2",
    className
  );
  const icon = arrow ? (
    external || href ? (
      <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden />
    ) : (
      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
    )
  ) : null;
  if (href)
    return (
      <a href={href} target="_blank" rel="noreferrer" className={cls}>
        {children}
        {icon}
      </a>
    );
  return (
    <Link to={to} className={cls}>
      {children}
      {icon}
    </Link>
  );
}

/* Status ------------------------------------------------------------- */

/** Small sentence-case status chip: green dot, label, optional green state word. */
export function Status({ label, state, className }) {
  return (
    <span className={cn("status-text inline-flex items-center gap-2 rounded-[4px] bg-surface px-2.5 py-1.5 text-ink", className)}>
      <span className="h-2 w-2 rounded-full bg-primary" aria-hidden />
      <span>{label}</span>
      {state && <span className="font-medium text-primary">{state}</span>}
    </span>
  );
}

/** The two hero statuses used across the site. */
export function StatusRow({ className }) {
  return (
    <div className={cn("flex flex-wrap gap-3", className)}>
      <Status label="EITL Governance Framework" state="Active" />
      <Status label="Truth Engine:" state="Live" />
    </div>
  );
}

/* Headings ----------------------------------------------------------- */

export function SectionHeading({ title, intro, as: Tag = "h2", className, light }) {
  return (
    <div className={cn("max-w-[44rem]", className)}>
      <Tag className={cn("section-title", light ? "text-primary-ink" : "text-ink")}>{title}</Tag>
      {intro && <p className={cn("mt-4 text-[18px] leading-[1.55]", light ? "text-primary-ink/85" : "text-muted")}>{intro}</p>}
    </div>
  );
}

/* Form fields -------------------------------------------------------- */

const fieldCls =
  "mt-2 block w-full rounded-[4px] border border-ink/20 bg-bg px-4 text-[16px] text-ink placeholder:text-muted/70 transition-colors focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20";

export function Field({ label, name, type = "text", required, optional, hint, textarea, rows = 6, className, inputClassName, ...rest }) {
  const id = `f-${name}`;
  return (
    <div className={className}>
      <label htmlFor={id} className="block text-[15px] font-medium text-ink">
        {label}
        {optional && <span className="font-normal text-muted"> (optional)</span>}
      </label>
      {textarea ? (
        <textarea id={id} name={name} required={required} rows={rows} className={cn(fieldCls, "py-3 leading-[1.5]", inputClassName)} {...rest} />
      ) : (
        <input id={id} name={name} type={type} required={required} className={cn(fieldCls, inputClassName || "h-12")} {...rest} />
      )}
      {hint && <p className="mt-1.5 text-[14px] text-muted">{hint}</p>}
    </div>
  );
}

/* Topic choosing ----------------------------------------------------- */

/** Remember a topic and open the Contact page with it preselected. */
export function useOpenTopic() {
  const navigate = useNavigate();
  return (topicId) => {
    if (topicId) storage.set("contact-topic", topicId);
    navigate(contactHref(topicId));
  };
}

/**
 * Bordered route buttons, one per inbox. Each opens Contact with that inbox chosen.
 * `ids` limits which topics appear. Full width 52px on phones.
 */
export function TopicRoutes({ ids, className, buttonClassName }) {
  const open = useOpenTopic();
  const list = ids ? TOPICS.filter((t) => ids.includes(t.id)) : TOPICS;
  return (
    <div className={cn("grid grid-cols-2 gap-2 sm:flex sm:flex-row sm:flex-wrap sm:gap-3", className)}>
      {list.map((t) => (
        <button
          key={t.id}
          type="button"
          onClick={() => open(t.id)}
          className={cn(
            "min-h-[52px] w-full rounded-[4px] border border-ink/25 bg-bg px-3 text-[15px] font-medium text-ink transition-[color,border-color,box-shadow] duration-150 hover:border-primary hover:bg-primary/5 hover:text-primary hover:shadow-[inset_3px_0_0_#0F6B4F] active:scale-[0.98] sm:w-auto sm:min-h-[64px] sm:px-6 sm:text-[16px]",
            buttonClassName
          )}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}

/** Compact topic select + Send a message button. Passes the choice to Contact. */
export function TopicSelect({ ids, defaultTopic = "general", light, className, label = "Topic" }) {
  const open = useOpenTopic();
  const list = ids ? TOPICS.filter((t) => ids.includes(t.id)) : TOPICS;
  const [topic, setTopic] = useState(list.some((t) => t.id === defaultTopic) ? defaultTopic : list[0].id);
  return (
    <form
      className={cn("flex flex-col gap-3 sm:flex-row sm:items-end", className)}
      onSubmit={(e) => {
        e.preventDefault();
        open(topic);
      }}
    >
      <div className="flex-1">
        <label htmlFor="topic-select" className={cn("block text-[15px] font-medium", light ? "text-primary-ink" : "text-ink")}>
          {label}
        </label>
        <select
          id="topic-select"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          className="mt-2 block h-12 w-full rounded-[4px] border border-ink/20 bg-bg px-3 text-[16px] text-ink focus:border-primary focus:outline-none"
        >
          {list.map((t) => (
            <option key={t.id} value={t.id}>
              {t.label}
            </option>
          ))}
        </select>
      </div>
      <button type="submit" className={light ? btnOnDark : btnPrimary}>
        Send a message
      </button>
    </form>
  );
}
