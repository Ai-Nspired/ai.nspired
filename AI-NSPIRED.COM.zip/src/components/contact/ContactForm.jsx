import { useForm, SpamTrap, cn } from "@wron/kit";
import { TOPICS, NOT_REPRESENTATION } from "../../data/site";
import { Field, btnPrimary } from "../ui";

export default function ContactForm({ topic, onTopic }) {
  const form = useForm("contact");
  const current = TOPICS.find((t) => t.id === topic) || TOPICS[4];

  return (
    <div className="rounded-[4px] border border-line bg-surface p-4 sm:p-6 lg:p-8">
      <div role="radiogroup" aria-label="Topic" className="flex flex-col border border-ink/20 bg-bg sm:flex-row">
        {TOPICS.map((t) => {
          const on = t.id === topic;
          return (
            <button
              key={t.id}
              type="button"
              role="radio"
              aria-checked={on}
              onClick={() => onTopic(t.id)}
              className={cn(
                "min-h-[52px] flex-1 border-b border-ink/15 px-3 text-[15px] font-medium transition-colors duration-150 last:border-b-0 sm:border-b-0 sm:border-r sm:last:border-r-0",
                on ? "bg-primary text-primary-ink" : "text-primary hover:bg-surface"
              )}
            >
              {t.label}
            </button>
          );
        })}
      </div>

      <form onSubmit={form.onSubmit} className="mt-6 space-y-5">
        <input type="hidden" name="topic" value={current.label} />
        <SpamTrap />
        <Field label="Name" name="name" required placeholder="Your name" autoComplete="name" />
        <Field label="Email" name="email" type="email" required placeholder="you@domain.com" autoComplete="email" />
        <Field label="Organization" name="organization" optional placeholder="Your organization" autoComplete="organization" />
        <Field label="Message" name="message" textarea rows={6} required placeholder="Tell us what you're contacting us about" />
        <button type="submit" disabled={form.sending} className={cn(btnPrimary, "w-full disabled:opacity-60")}>
          Send message
        </button>

        <div aria-live="polite" className="space-y-3">
          {form.sending && (
            <div className="rounded-[4px] border border-line bg-bg p-4 text-[16px] text-muted">
              <p>Sending your message to the selected inbox.</p>
              <div className="mt-3 h-0.5 overflow-hidden bg-line">
                <div className="h-full w-1/3 animate-pulse bg-primary" />
              </div>
            </div>
          )}
          {form.sent && (
            <p className="rounded-[4px] border border-primary/30 bg-primary/5 p-4 text-[16px] text-muted">
              <span className="font-medium text-ink">Message received.</span> It has been routed to the selected inbox.
            </p>
          )}
          {form.error && (
            <p className="rounded-[4px] border border-red-300 bg-red-50 p-4 text-[16px] text-[#7A1F2E]">
              Your message could not be sent. Your text is still here, so you can try again.
            </p>
          )}
        </div>
        <p className="text-center text-[15px] text-muted">
          Prefer email? Write to{" "}
          <a href={`mailto:${current.email}`} className="font-medium text-primary underline underline-offset-4 hover:text-[#0B5540]">
            {current.email}
          </a>
          .
        </p>
        <p className="text-center text-[15px] text-muted">{NOT_REPRESENTATION}</p>
      </form>
    </div>
  );
}
