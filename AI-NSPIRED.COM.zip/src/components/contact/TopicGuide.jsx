import { Reveal, scrollToSection, cn } from "@wron/kit";
import { TOPICS } from "../../data/site";

export default function TopicGuide({ topic, onTopic }) {
  return (
    <section className="page-wrap py-12 md:py-16">
      <h2 className="section-title text-ink">Topic guide</h2>
      <p className="mt-3 max-w-[40rem] text-[18px] leading-[1.55] text-muted">
        Use the form, or write straight to the inbox for your topic.
      </p>
      <ul className="mt-8 space-y-3">
        {TOPICS.map((t, i) => {
          const on = t.id === topic;
          return (
            <Reveal key={t.id} delay={i * 0.07} as="li">
              <div
                className={cn(
                  "flex flex-col border border-line bg-bg transition-shadow duration-150 hover:shadow-[inset_3px_0_0_#0F6B4F] md:flex-row md:items-stretch",
                  on && "shadow-[inset_3px_0_0_#0F6B4F]"
                )}
              >
                <button
                  type="button"
                  onClick={() => {
                    onTopic(t.id);
                    scrollToSection("message");
                  }}
                  aria-pressed={on}
                  className="grid flex-1 gap-1 px-5 py-5 text-left md:grid-cols-[16rem_1fr] md:items-center md:gap-0 md:px-8"
                >
                  <span className={cn("text-[22px] font-medium", on ? "text-primary" : "text-ink")}>{t.label}</span>
                  <span className="text-[16px] text-muted md:border-l md:border-line md:pl-8">{t.description}</span>
                </button>
                <a
                  href={`mailto:${t.email}`}
                  className="flex min-h-[48px] items-center border-t border-line px-5 py-3 text-[16px] font-medium text-primary underline decoration-1 underline-offset-[5px] transition-colors hover:text-[#0B5540] md:w-[17rem] md:border-l md:border-t-0 md:px-6"
                >
                  <span className="break-all">{t.email}</span>
                </a>
              </div>
            </Reveal>
          );
        })}
      </ul>
    </section>
  );
}
