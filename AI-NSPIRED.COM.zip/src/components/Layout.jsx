import { Link, NavLink, Outlet } from "react-router";
import { Menu, X } from "lucide-react";
import { Sheet, useDisclosure, CookieSettingsLink, cn } from "@wron/kit";
import { NAV, NOTICE, NOT_REPRESENTATION, COPYRIGHT, FOOTER_LINKS, SITE_NAME } from "../data/site";
import { btnPrimary } from "./ui";

function Wordmark({ className }) {
  return (
    <Link
      to="/"
      aria-label="AI-NSPIRED.COM, home"
      className={cn("whitespace-nowrap font-display font-semibold tracking-[-0.02em] text-ink", className)}
    >
      {SITE_NAME}
    </Link>
  );
}

export default function Layout() {
  const menu = useDisclosure();

  return (
    <div className="flex min-h-screen flex-col bg-bg font-body text-ink">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:bg-bg focus:p-3">
        Skip to content
      </a>

      {/* Notice bar */}
      <div className="bg-surface">
        <p className="page-wrap py-2 text-center text-[13px] leading-[1.35] text-muted md:py-[9px]">{NOTICE}</p>
      </div>

      {/* Header */}
      <header className="relative z-40 border-b border-line bg-bg">
        <div className="page-wrap flex h-20 items-center justify-between gap-3 md:h-24">
          <Wordmark className="min-w-0 text-[19px] min-[400px]:text-[22px] md:text-[32px] lg:text-[34px]" />
          <nav aria-label="Main" className="hidden items-center gap-1 lg:flex">
            {NAV.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                className={({ isActive }) =>
                  cn(
                    "rounded-[4px] px-4 py-2 text-[15px] font-[550] transition-colors duration-150 hover:text-primary",
                    isActive ? "text-primary" : "text-ink"
                  )
                }
              >
                {n.label}
              </NavLink>
            ))}
            <Link to="/contact#message" className={cn(btnPrimary, "ml-5 text-[15px]")}>
              Send a message
            </Link>
          </nav>
          <div className="flex shrink-0 items-center gap-2 lg:hidden">
            <Link
              to="/contact#message"
              className="inline-flex min-h-[40px] items-center rounded-[4px] bg-primary px-3 text-[14px] font-medium text-primary-ink transition-colors hover:bg-[#0B5540] sm:min-h-[44px] sm:px-4 sm:text-[15px]"
            >
              Send a message
            </Link>
            <button
              type="button"
              onClick={menu.onOpen}
              aria-label="Open menu"
              className="inline-flex h-10 w-10 items-center justify-center rounded-[4px] border border-line text-ink hover:bg-surface sm:h-11 sm:w-11"
            >
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      <Sheet open={menu.open} onClose={menu.onClose} side="right" panelClassName="bg-bg w-[86%] max-w-sm">
        <div className="flex h-full flex-col p-6">
          <div className="flex items-center justify-between">
            <span className="text-[17px] font-semibold">{SITE_NAME}</span>
            <button
              type="button"
              onClick={menu.onClose}
              aria-label="Close menu"
              className="inline-flex h-11 w-11 items-center justify-center rounded-[4px] border border-line"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <nav aria-label="Mobile" className="mt-8 flex flex-col border-t border-line">
            <NavLink to="/" end onClick={menu.onClose} className="border-b border-line py-4 text-[20px] font-medium">
              Home
            </NavLink>
            {NAV.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                onClick={menu.onClose}
                className={({ isActive }) =>
                  cn("border-b border-line py-4 text-[20px] font-medium", isActive ? "text-primary" : "text-ink")
                }
              >
                {n.label}
              </NavLink>
            ))}
          </nav>
          <Link to="/contact#message" onClick={menu.onClose} className={cn(btnPrimary, "mt-8 w-full")}>
            Send a message
          </Link>
          <p className="mt-auto pt-6 text-[14px] text-muted">{NOT_REPRESENTATION}</p>
        </div>
      </Sheet>

      <div id="main" className="flex-1">
        <Outlet />
      </div>

      {/* Footer */}
      <footer className="border-t border-line bg-surface">
        <div className="page-wrap grid gap-10 py-14 md:grid-cols-12">
          <div className="md:col-span-5">
            <Wordmark className="text-[22px]" />
            <p className="mt-4 max-w-sm text-[16px] text-muted">
              Human-guided AI systems that make reasoning visible, testable and editable by experts.
            </p>
            <Link to="/contact#message" className={cn(btnPrimary, "mt-6")}>
              Send a message
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-8 md:col-span-7 md:grid-cols-3">
            <div>
              <p className="text-[15px] font-semibold text-ink">Systems</p>
              <ul className="mt-3 space-y-1">
                {FOOTER_LINKS.systems.map((l) => (
                  <li key={l.to}>
                    <Link to={l.to} className="inline-flex min-h-[40px] items-center text-[15px] text-muted hover:text-primary">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[15px] font-semibold text-ink">Ecosystem</p>
              <ul className="mt-3 space-y-1">
                {FOOTER_LINKS.ecosystem.map((l) => (
                  <li key={l.href + l.label}>
                    <a
                      href={l.href}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex min-h-[40px] items-center text-[15px] text-muted hover:text-primary"
                    >
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[15px] font-semibold text-ink">Policies</p>
              <ul className="mt-3 space-y-1">
                <li>
                  <Link to="/terms-privacy" className="inline-flex min-h-[40px] items-center text-[15px] text-muted hover:text-primary">
                    Terms & Privacy
                  </Link>
                </li>
                <li>
                  <CookieSettingsLink className="inline-flex min-h-[40px] items-center text-[15px] text-muted hover:text-primary">
                    Cookie settings
                  </CookieSettingsLink>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="border-t border-line">
          <div className="page-wrap flex flex-col gap-2 py-6 text-[14px] text-muted md:flex-row md:justify-between">
            <p>{NOT_REPRESENTATION} {NOTICE}</p>
            <p className="shrink-0">{COPYRIGHT}</p>
          </div>
        </div>
      </footer>


    </div>
  );
}
