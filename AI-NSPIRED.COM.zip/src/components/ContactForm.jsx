import { useEffect, useState } from "react";
import { useSearchParams } from "react-router";
import { useForm, SpamTrap, storage, cn } from "@wron/kit";
import { TOPICS, topicById, NOT_REPRESENTATION } from "../data/site";
import { Field, btnPrimary } from "./ui";

/** The topic picker: segmented on desktop, a vertical radio group on phones. Controlled. */
export function TopicChooser({ value, onChange, ids, legend = "Topic" }) {
  const list = ids ? TOPICS.filter((t) => ids.includes(t.id)) : TOPICS;
  return (
    <fieldset>
      <legend className="text-[15px] font-medium text-ink">{legend}</legend>
      <div className="mt-2 flex flex-col overflow-hidden rounded-[4px] border border-ink/20 md:flex-row">
        {list.map((t, i) => {
          const on = value === t.id;
          return (
            <label
              key={t.id}
              className={cn(
                "relative flex min-h-[48px] flex-1 cursor-pointer items-center gap-3 px-4 text-[15px] font-medium transition-colors duration-150 md:justify-center md:px-3 md:text-center",
                i > 0 && "border-t border-ink/20 md:border-l md:border-t-0",
                on ? "bg-primary text-primary-ink" : "bg-bg text-ink hover:bg-surface"
              )}
            >
              <input
                type="radio"
                name="topic"
                value={t.label}
                checked={on}
                onChange={() => onChange(t.id)}
                className="h-4 w-4 accent-[#0F6B4F] md:sr-only"
              />
              {t.label}
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}

/** Reads ?topic= or the remembered topic, falling back to `fallback`. */
export function useContactTopic(fallback = "general") {
  const [params] = useSearchParams();
  const [topic, setTopicState] = useState(fallback);
  const fromUrl = params.get("topic");
  useEffect(() => {
    const t = fromUrl || storage.get("contact-topic");
    if (t && topicById(t)) setTopicState(t);
  }, [fromUrl]);
  const setTopic = (t) => {
    setTopicState(t);
    storage.set("contact-topic", t);
  };
  return [topic, setTopic];
}

/**
 * The routed contact form. Every entry carries its inbox as "topic".
 * Pass `topic`/`onTopicChange` to control it from outside (the Contact page topic guide),
 * or leave them out and it reads ?topic= itself.
 */
export default function ContactForm({ topic: controlled, onTopicChange, ids, className, showNotice = true }) {
  const form = useForm("contact");
  const [own, setOwn] = useContactTopic(ids ? ids[0] : "general");
  const topic = controlled ?? own;
  const setTopic = onTopicChange ?? setOwn;
  const current = topicById(topic);

  if (form.sent) {
    return (
      <div className={cn("rounded-[10px] border border-line bg-bg p-6 sm:p-8", className)} role="status">
        <p className="status-text inline-flex items-center gap-2 text-primary">
          <span className="h-2 w-2 rounded-full bg-primary" aria-hidden /> {current?.label}
        </p>
        <h3 className="mt-3 text-[28px] leading-[1.1] text-ink">Message received.</h3>
        <p className="mt-3 text-[18px] text-muted">It has been routed to the selected inbox. Messages are triaged daily.</p>
        <button type="button" onClick={form.reset} className={cn(btnPrimary, "mt-6")}>
          Send another message
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={form.onSubmit} className={cn("rounded-[10px] border border-line bg-bg p-5 sm:p-8", className)}>
      <SpamTrap />
      <TopicChooser value={topic} onChange={setTopic} ids={ids} />
      <input type="hidden" name="inbox" value={current?.label || ""} />
      <div className="mt-6 grid gap-5 md:grid-cols-2">
        <Field label="Name" name="name" required autoComplete="name" />
        <Field label="Email" name="email" type="email" required autoComplete="email" />
        <Field label="Organization" name="organization" optional autoComplete="organization" className="md:col-span-2" />
        <Field label="Message" name="message" textarea required className="md:col-span-2" />
      </div>
      <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-center">
        <button type="submit" disabled={form.sending} className={cn(btnPrimary, "disabled:cursor-wait disabled:opacity-70")}>
          {form.sending ? "Sending..." : "Send message"}
        </button>
        {current && <p className="text-[15px] text-muted">Goes to: {current.label}</p>}
      </div>
      <div className="mt-4 min-h-[24px] text-[15px]" aria-live="polite">
        {form.sending && (
          <div>
            <p className="text-muted">Sending your message to the selected inbox.</p>
            <div className="mt-2 h-0.5 w-full overflow-hidden bg-line">
              <div className="h-full w-1/3 animate-pulse bg-primary" />
            </div>
          </div>
        )}
        {form.error && !form.sending && (
          <p className="text-[#9B2C1F]">
            Your message could not be sent. Your text is still here, so you can try again. {String(form.error)}
          </p>
        )}
      </div>
      {showNotice && <p className="mt-4 border-t border-line pt-4 text-[14px] text-muted">{NOT_REPRESENTATION}</p>}
    </form>
  );
}
