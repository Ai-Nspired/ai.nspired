import { Reveal } from "@wron/kit";
import { Link } from "react-router";
import { ArrowRight } from "lucide-react";

const STEPS = [
  { n: "01", title: "Pull from real sources" },
  { n: "02", title: "Cross-reference claims and surface contradictions" },
  { n: "03", title: "Return layered, confidence-rated answers backed by receipts" },
];

export default function Method() {
  return (
    <section aria-labelledby="method-title" className="bg-surface">
      <div className="page-wrap py-16 md:py-24">
        <Reveal y={12}>
          <h2 id="method-title" className="section-title text-ink">
            How clarity is built
          </h2>
        </Reveal>

        <ol className="mt-10 grid border-y border-ink/15 lg:grid-cols-[1fr_1fr_1fr_0.85fr] lg:divide-x lg:divide-ink/15">
          {STEPS.map(({ n, title }, i) => (
            <Reveal
              as="li"
              key={n}
              y={12}
              delay={i * 0.07}
              className="border-b border-ink/15 py-8 last:border-b-0 lg:border-b-0 lg:px-8 lg:py-14 lg:first:pl-0"
            >
              <p className="ledger text-4xl font-semibold leading-none tracking-[-0.035em] text-ink lg:text-[56px]">{n}</p>
              <h3 className="mt-4 max-w-[16rem] text-[20px] font-semibold leading-[1.2] tracking-[-0.02em] text-ink">{title}</h3>
            </Reveal>
          ))}
          <Reveal
            as="li"
            y={12}
            delay={0.21}
            className="flex flex-col justify-center gap-4 border-t border-ink/15 py-8 lg:border-t-0 lg:px-8 lg:py-14"
          >
            <p className="text-[clamp(24px,2.2vw,30px)] font-semibold leading-[1.15] tracking-[-0.025em] text-ink">
              Expert review stays in the loop.
            </p>
            <Link
              to="/eitl"
              className="group inline-flex min-h-[44px] items-center gap-1.5 text-[16px] font-medium text-primary underline decoration-1 underline-offset-[5px] hover:decoration-2"
            >
              See how EITL keeps humans accountable
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
            </Link>
          </Reveal>
        </ol>
      </div>
    </section>
  );
}
