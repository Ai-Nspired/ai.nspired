import { motion, useReducedMotion } from "motion/react";
import { FileText, Link2, TriangleAlert, User, CircleHelp } from "lucide-react";
import { cn } from "@wron/kit";

const ROWS = [
  { icon: FileText, title: "Source", sub: "Verified source material and citations", state: "Documented", tone: "neutral" },
  { icon: Link2, title: "Claim", sub: "Extracted claim and key assertions", state: "Identified", tone: "neutral" },
  { icon: TriangleAlert, title: "Conflict", sub: "Contradictory information detected", state: "Requires review", tone: "conflict" },
  { icon: User, title: "Expert review", sub: "Human expert analysis and validation", state: "Human accountable", tone: "human" },
  { icon: CircleHelp, title: "Next question", sub: "Open questions and areas for further research", state: "Queued", tone: "neutral" },
];

const CELL = {
  neutral: "#ECEEEA",
  conflict: "#F5CD70",
  human: "#0F6B4F",
};
const EASE = [0.16, 1, 0.3, 1];

export default function EvidenceLedger({ className }) {
  const reduce = useReducedMotion();

  return (
    <div className={cn("ledger flex flex-col rounded-[10px] border border-line bg-bg p-4 sm:p-5", className)}>
      <p className="px-1 text-[19px] font-semibold tracking-[-0.02em] text-ink sm:text-[20px]">Evidence Ledger</p>
      <ol className="relative mt-4 flex flex-1 flex-col gap-2" aria-label="Evidence ledger, from source to next question">
        {/* The source-to-review path */}
        <span aria-hidden className="absolute bottom-7 left-[7px] top-7 w-[2px] bg-ink/80" />
        {ROWS.map((r, i) => {
          const Icon = r.icon;
          const conflict = r.tone === "conflict";
          const human = r.tone === "human";
          return (
            <motion.li
              key={r.title}
              initial={reduce ? false : { opacity: 0, y: 12 }}
              whileInView={reduce ? undefined : { opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.4, delay: 0.15 + i * 0.07, ease: EASE }}
              className="relative flex flex-1 items-stretch pl-5 sm:pl-6"
            >
              <span aria-hidden className="absolute left-[3px] top-1/2 h-[10px] w-[10px] -translate-y-1/2 rounded-full bg-ink" />
              <div
                className={cn(
                  "grid flex-1 grid-cols-[1fr_auto] overflow-hidden rounded-[6px] border sm:grid-cols-[1fr_9.5rem]",
                  conflict ? "border-[#EBC36A] bg-[#FBE6B7]" : "border-line bg-bg"
                )}
              >
                <div className="flex min-w-0 items-center gap-2.5 px-2.5 py-3 sm:gap-4 sm:px-4">
                  <Icon className="h-6 w-6 shrink-0 text-ink" strokeWidth={1.5} aria-hidden />
                  <div className="min-w-0">
                    <p className="text-[17px] font-medium leading-[1.25] text-ink">{r.title}</p>
                    <p className="mt-0.5 text-[14px] leading-[1.35] text-ink/70">{r.sub}</p>
                  </div>
                </div>
                <motion.div
                  initial={reduce ? false : { backgroundColor: CELL[r.tone] }}
                  whileInView={
                    reduce
                      ? undefined
                      : { backgroundColor: human || conflict ? CELL[r.tone] : ["#ECEEEA", "#D6E9DF", "#ECEEEA"] }
                  }
                  viewport={{ once: true, amount: 0.4 }}
                  transition={{ duration: 1.1, delay: 0.45 + i * 0.07, ease: "easeOut" }}
                  style={{ backgroundColor: CELL[r.tone] }}
                  className={cn(
                    "flex w-[6.5rem] items-center border-l px-2.5 text-sm font-medium leading-[1.3] sm:w-auto sm:px-4 sm:text-[13px]",
                    conflict ? "border-[#EBC36A] text-ink" : human ? "border-primary text-primary-ink" : "border-line text-ink"
                  )}
                >
                  {r.state}
                </motion.div>
              </div>
            </motion.li>
          );
        })}
      </ol>
    </div>
  );
}
