import { Reveal } from "@wron/kit";
import { PRINCIPLES } from "../../data/site";

export default function Principles() {
  return (
    <section aria-labelledby="principles-title" className="bg-primary text-primary-ink">
      <div className="page-wrap py-20 md:py-28">
        <h2 id="principles-title" className="sr-only">
          Our principles
        </h2>
        <div className="grid md:grid-cols-3">
          {PRINCIPLES.map((p, i) => (
            <Reveal
              key={p.name}
              y={12}
              delay={i * 0.07}
              className="border-primary-ink/30 py-8 text-center first:pt-0 last:pb-0 max-md:border-b max-md:last:border-b-0 md:px-8 md:py-4 md:[&:not(:first-child)]:border-l"
            >
              <h3 className="text-[clamp(36px,3.6vw,52px)] font-semibold leading-[1] tracking-[-0.035em]">{p.name}</h3>
              <p className="mx-auto mt-5 max-w-[19rem] text-[17px] leading-[1.6] text-primary-ink/90">{p.short}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
