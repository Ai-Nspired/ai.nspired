import { Reveal } from "@wron/kit";
import { TopicSelect } from "../ui";

export default function Closing() {
  return (
    <section aria-labelledby="closing-title" className="bg-bg">
      <div className="page-wrap grid-12 items-end gap-y-8 py-16 md:py-24">
        <Reveal y={12} className="lg:col-span-7">
          <h2 id="closing-title" className="section-title max-w-[40rem] text-ink">
            Put the right context in front of the right inbox
          </h2>
          <p className="mt-4 max-w-[34rem] text-[18px] leading-[1.55] text-muted">
            Pick the inbox that fits. The Contact form opens with it already chosen. We triage daily.
          </p>
        </Reveal>
        <Reveal y={12} delay={0.08} className="lg:col-span-5">
          <TopicSelect label="Choose a topic" />
        </Reveal>
      </div>
    </section>
  );
}
