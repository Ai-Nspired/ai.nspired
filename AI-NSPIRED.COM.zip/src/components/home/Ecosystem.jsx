import { Link } from "react-router";
import { Img, Reveal, cn } from "@wron/kit";
import { ECOSYSTEM } from "../../data/site";
import { TILE_IMG, TILE_ALT } from "./images";

const tileCls =
  "group flex h-full flex-col border border-slate-300 bg-bg p-4 transition-[border-color,box-shadow] duration-150 hover:border-primary hover:shadow-[inset_3px_0_0_#0F6B4F] sm:p-5";

function TileLink({ item, children }) {
  if (item.href)
    return (
      <a href={item.href} target="_blank" rel="noreferrer" className={tileCls}>
        {children}
      </a>
    );
  return (
    <Link to={item.to} className={tileCls}>
      {children}
    </Link>
  );
}

function Tile({ item, title = "text-[24px] lg:text-[28px]", delay = 0, className }) {
  return (
    <Reveal y={12} delay={delay} className={cn(className)}>
      <TileLink item={item}>
        <Img
          src={TILE_IMG[item.id === "eitl" ? "ai-counsel" : item.id]}
          alt={item.id === "eitl" ? TILE_ALT["ai-counsel"] : TILE_ALT[item.id]}
          ratio="16/9"
          imgClassName="object-cover"
          sizes="(min-width:1024px) 40vw, 100vw"
        />
        <div className="mt-5 flex flex-1 flex-col px-1">
          <h3 className={cn("font-semibold leading-[1.1] text-ink", title)}>{item.name}</h3>
          <p className="mt-2 max-w-[28rem] text-[16px] leading-[1.5] text-muted">{item.body}</p>
          {item.href && <span className="sr-only"> (opens another site)</span>}
        </div>
      </TileLink>
    </Reveal>
  );
}

export default function Ecosystem() {
  const [te, eitl, counsel, university, speakeasy] = ECOSYSTEM;

  return (
    <section aria-labelledby="eco-title" className="page-wrap py-16 md:py-24">
      <Reveal y={12}>
        <h2 id="eco-title" className="section-title text-ink">
          The complete Truth Engine ecosystem
        </h2>
        <p className="mt-4 max-w-[40rem] text-[18px] leading-[1.55] text-muted">
          One methodology, one governance framework and three places to apply it. Each part feeds the next.
        </p>
      </Reveal>

      <div className="mt-10 grid gap-5 md:grid-cols-2">
        <Tile item={te} />
        <Tile item={eitl} delay={0.07} />
      </div>

      <div className="mt-5 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {[counsel, university, speakeasy].map((item, i) => (
          <Tile
            key={item.id}
            item={item}
            title="text-[24px]"
            delay={i * 0.07}
            className={i === 2 ? "sm:col-span-2 lg:col-span-1" : ""}
          />
        ))}
      </div>
    </section>
  );
}
