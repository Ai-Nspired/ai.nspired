export const HERO_IMG =
  "https://firebasestorage.googleapis.com/v0/b/wron-ai.firebasestorage.app/o/site-assets%2Fsite-1792355216118%2F5f397e0f-8aee-4876-ad41-981adcba57d4.webp?alt=media&token=df97cf2a-8846-4cf9-80d4-7bdf2ff94a6d";

export const TILE_IMG = {
  "truth-engine":
    "https://firebasestorage.googleapis.com/v0/b/wron-ai.firebasestorage.app/o/site-assets%2Fsite-1792355216118%2F5e99db62-45e6-406b-9864-93ed1f049fa1.webp?alt=media&token=3418371f-c4b7-42fa-baee-cc0903b30e0e",
  "ai-counsel":
    "https://firebasestorage.googleapis.com/v0/b/wron-ai.firebasestorage.app/o/site-assets%2Fsite-1792355216118%2F0ec4a34a-dd80-414d-b074-7b3fc26c0121.webp?alt=media&token=257bc640-ddd1-43f2-a737-6f6d9f464663",
  "ai-university":
    "https://firebasestorage.googleapis.com/v0/b/wron-ai.firebasestorage.app/o/site-assets%2Fsite-1792355216118%2F33e6b5ad-90d2-45c5-b883-5346b80b7b76.webp?alt=media&token=f959c69e-a85d-4dee-9e59-9237b751cbd0",
  speakeasy:
    "https://firebasestorage.googleapis.com/v0/b/wron-ai.firebasestorage.app/o/site-assets%2Fsite-1792355216118%2Fe1259156-1a1f-467a-ace3-7496f5f749b9.webp?alt=media&token=729586c7-53bc-4ec2-ba14-2f11a8ba4176",
};

export const TILE_ALT = {
  "truth-engine": "Hands typing on a laptop showing a document review screen",
  "ai-counsel": "A leather folder and a pen on a pale wooden table",
  "ai-university": "A stack of books beside a laptop in a library",
  speakeasy: "An empty meeting room with a long table and city windows",
};
