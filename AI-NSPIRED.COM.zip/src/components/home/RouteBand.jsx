import { Reveal } from "@wron/kit";
import { Link } from "react-router";
import { TopicRoutes } from "../ui";

export default function RouteBand() {
  return (
    <section aria-labelledby="routes-title" className="bg-surface">
      <div className="page-wrap grid grid-cols-1 items-center gap-y-7 py-12 md:py-14 xl:grid-cols-[minmax(0,1fr)_auto] xl:gap-x-10">
        <Reveal y={12} className="min-w-0">
          <h2 id="routes-title" className="text-[clamp(28px,2.6vw,34px)] font-semibold leading-tight tracking-[-0.035em] text-ink xl:whitespace-nowrap xl:text-[32px]">
            Start with the right conversation
          </h2>
          <p className="mt-3 text-[16px] leading-[1.55] text-muted md:text-[17px]">
            Choose a topic and your message will be routed to the right inbox.
          </p>
        </Reveal>
        <Reveal y={12} delay={0.08}>
          <TopicRoutes className="xl:flex-nowrap xl:justify-end" buttonClassName="sm:px-5 xl:px-4 xl:whitespace-nowrap" />
          <Link
            to="/contact#message"
            className="mt-6 flex h-14 w-full items-center justify-center rounded-[4px] bg-primary text-[18px] text-primary-ink md:hidden"
          >
            Send a message
          </Link>
        </Reveal>
      </div>
    </section>
  );
}
