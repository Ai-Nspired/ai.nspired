import { Reveal, Img, cn } from "@wron/kit";
import { Link } from "react-router";
import { StatusRow, btnPrimary } from "../ui";
import EvidenceLedger from "./EvidenceLedger";
import { HERO_IMG } from "./images";

export default function Hero() {
  return (
    <section className="page-wrap !max-w-[1320px] pb-14 pt-8 md:pt-12 lg:pb-8 lg:pt-7">
      <div className="grid grid-cols-1 items-start gap-y-8 lg:grid-cols-[1.02fr_0.98fr] lg:gap-10">
        <div className="min-w-0 lg:pt-10">
          <Reveal y={12}>
            <StatusRow className="[&_.status-text]:text-sm" />
          </Reveal>
          <Reveal y={12} delay={0.05}>
            <h1 className="hero-title mt-6 max-w-none text-[44px] leading-[0.98] tracking-[-0.04em] text-ink lg:mt-9 lg:text-[54px] lg:tracking-[-0.045em] xl:text-[62px]">
              Human-guided AI systems for founders and operators facing legal risk.
            </h1>
          </Reveal>
          <Reveal y={12} delay={0.1}>
            <p className="mt-6 max-w-[34rem] text-[18px] leading-7 text-muted lg:text-[20px]">
              Make reasoning visible, testable and editable by experts before uncertainty becomes action.
            </p>
          </Reveal>
          <Reveal y={12} delay={0.15}>
            <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:gap-7 lg:mt-10">
              <Link to="/contact#message" className={cn(btnPrimary, "h-14 w-full px-10 text-[18px] sm:h-auto sm:w-auto sm:text-[17px]")}>
                Send a message
              </Link>
              <Link
                to="/truth-engine#audit"
                className="inline-flex min-h-[44px] items-center text-[17px] font-medium text-primary underline decoration-1 underline-offset-[6px] transition-colors hover:text-[#0B5540] hover:decoration-2"
              >
                Audit a docket free
              </Link>
            </div>
          </Reveal>
        </div>

        <div className="min-w-0">
          {/* Desktop: ledger over the desk photograph */}
          <div className="relative hidden overflow-hidden rounded-[2px] lg:block">
            <div className="absolute inset-0">
              <Img
                src={HERO_IMG}
                alt="A person typing on a laptop at a bright office desk"
                className="h-full w-full"
                imgClassName="h-full w-full object-cover"
                priority
                sizes="(min-width:1024px) 45vw, 100vw"
              />
            </div>
            <div className="relative pb-[18%] pl-[14%] pr-[2.5%] pt-[4%]">
              <div className="w-full rounded-[10px] bg-bg/80 p-2 backdrop-blur-sm">
                <EvidenceLedger className="border-line/80" />
              </div>
            </div>
          </div>
          {/* Phones and tablets: the ledger alone */}
          <EvidenceLedger className="mt-8 min-h-[560px] w-full lg:hidden" />
        </div>
      </div>
    </section>
  );
}
