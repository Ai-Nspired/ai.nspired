import { contactHref } from "../../data/site";
import { TextLink } from "../ui";

export default function FounderSupport() {
  return (
    <section className="mt-10 bg-surface py-14 md:mt-16 md:py-16">
      <div className="page-wrap grid-12 items-center gap-y-8">
        <div className="lg:col-span-7">
          <h2 className="section-title">Support a tired solo founder</h2>
          <p className="mt-5 max-w-[40rem] text-[18px] leading-[1.55] text-muted">
            Truth Engine is 100% bootstrapped, built and maintained by a single developer. The audits are free because
            objective truth should not be hidden behind a paywall. If the system saved billable hours, flagged a costly
            legal blindspot or helped a case, consider supporting the coffee fund so the servers can keep humming.
          </p>
        </div>
        <div className="flex flex-col items-start lg:col-span-5 lg:items-end">
          <p className="max-w-[20rem] text-[16px] text-ink lg:text-right">
            Want to chip in? Send a message and we will share how to support the coffee fund.
          </p>
          <TextLink to={contactHref("general")} arrow className="mt-3">
            Ask how to support
          </TextLink>
        </div>
      </div>
    </section>
  );
}
