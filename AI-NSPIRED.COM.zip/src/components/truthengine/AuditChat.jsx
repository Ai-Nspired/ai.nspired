import { useState } from "react";
import { ai, cn } from "@wron/kit";
import { btnPrimary } from "../ui";
import Markdown from "./Markdown";

const SYSTEM =
  "You help a person understand a legal document they uploaded. Answer only from the document and the review already given. Quote the exact words you rely on. If the document does not say, say so. Never invent case law, rules or deadlines. Keep answers short and plain. This is educational, not legal advice.";

const textOf = (r) => (typeof r === "string" ? r : r?.content ?? r?.text ?? r?.message ?? String(r ?? ""));

/** Follow-up questions about the audited document. `base` holds the document and the report. */
export default function AuditChat({ base }) {
  const [turns, setTurns] = useState([]);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const ask = async (e) => {
    e.preventDefault();
    const question = q.trim();
    if (!question || busy) return;
    const next = [...turns, { role: "user", content: question }];
    setTurns(next);
    setQ("");
    setErr("");
    setBusy(true);
    try {
      const reply = await ai.chat([...base, ...next], { system: SYSTEM });
      setTurns([...next, { role: "assistant", content: textOf(reply) }]);
    } catch (e2) {
      setErr(e2?.message || "The answer could not be written. Try again.");
      setTurns(turns);
      setQ(question);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-8 border-t border-line pt-6">
      <h3 className="text-[20px] font-semibold tracking-[-0.02em]">Ask about this document</h3>
      {turns.length > 0 && (
        <ul className="mt-4 space-y-4" aria-live="polite">
          {turns.map((t, i) => (
            <li
              key={i}
              className={cn(
                "rounded-[4px] border p-4",
                t.role === "user" ? "border-line bg-surface" : "border-line border-l-[3px] border-l-primary bg-bg"
              )}
            >
              <p className="mb-1 text-[13px] font-medium text-muted">{t.role === "user" ? "Your question" : "Answer"}</p>
              {t.role === "user" ? <p className="text-[16px] text-ink">{t.content}</p> : <Markdown text={t.content} />}
            </li>
          ))}
        </ul>
      )}
      <form onSubmit={ask} className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-end">
        <div className="flex-1">
          <label htmlFor="audit-q" className="block text-[15px] font-medium">
            Your question
          </label>
          <input
            id="audit-q"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="mt-2 block h-12 w-full rounded-[4px] border border-ink/20 bg-bg px-4 text-[16px] focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
          />
        </div>
        <button type="submit" disabled={busy || !q.trim()} className={cn(btnPrimary, "disabled:opacity-60")}>
          {busy ? "Answering..." : "Ask question"}
        </button>
      </form>
      {busy && (
        <div className="mt-3 h-[3px] overflow-hidden bg-line" role="status" aria-label="Writing the answer">
          <div className="h-full w-1/3 animate-pulse bg-primary motion-reduce:animate-none" />
        </div>
      )}
      {err && (
        <p role="alert" className="mt-3 text-[15px] text-ink">
          {err}
        </p>
      )}
    </div>
  );
}
