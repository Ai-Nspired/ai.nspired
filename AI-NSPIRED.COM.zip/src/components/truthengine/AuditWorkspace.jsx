import { useRef, useState } from "react";
import { FileText, FileUp } from "lucide-react";
import { ai, toast, cn } from "@wron/kit";
import { Link } from "react-router";
import { NOTICE, EXTERNAL, contactHref } from "../../data/site";
import { btnPrimary } from "../ui";
import { extractText } from "../../lib/extract";
import Markdown from "./Markdown";
import AuditChat from "./AuditChat";

const OK = ["pdf", "docx", "txt"];
const MAX_CHARS = 60000;
const ext = (n) => (n.split(".").pop() || "").toLowerCase();
const textOf = (r) => (typeof r === "string" ? r : r?.content ?? r?.text ?? r?.message ?? String(r ?? ""));

const SYSTEM = `You review a legal document or docket for a person representing themselves. Work only from the text given. Write a plain, short, structured review in markdown with these headings, in this order:
## Summary
Two or three sentences on what the document is and what it does.
## Sources and key dates
Bullets: who filed or signed it, dates, case or document numbers, deadlines. Quote exact words.
## Claims
Bullets: each key assertion on its own line, with the exact words in quotes.
## Conflicts and unresolved points
Bullets: where the document contradicts itself or another stated fact (dates, names, amounts, orders). If none are found, say "No conflicts found in this text."
## Confidence
Bullets: for each finding, say High, Medium or Low confidence and why.
## Questions to ask next
Bullets: questions to put to a licensed attorney or the court clerk.
Rules: never invent case law, statutes, rules or deadlines. If the text is unclear or cut off, say so. Write at a 7th grade reading level. End with one line: "This is educational, not legal advice."`;

export default function AuditWorkspace() {
  const input = useRef(null);
  const [file, setFile] = useState(null);
  const [pasted, setPasted] = useState("");
  const [state, setState] = useState("empty"); // empty | ready | loading | done | failed
  const [step, setStep] = useState("");
  const [err, setErr] = useState("");
  const [report, setReport] = useState("");
  const [base, setBase] = useState([]);

  const pick = (f) => {
    if (!f) return;
    if (!OK.includes(ext(f.name))) {
      setFile(null);
      setState("failed");
      setErr("That file type is not supported. Use PDF, DOCX or TXT.");
      return;
    }
    setFile(f);
    setErr("");
    setState("ready");
  };

  const hasInput = !!file || pasted.trim().length > 0;

  const run = async () => {
    if (!hasInput) {
      input.current?.click();
      return;
    }
    setState("loading");
    setErr("");
    setReport("");
    try {
      setStep("Reading your document");
      let text = pasted.trim();
      if (file) text = [await extractText(file), text].filter(Boolean).join("\n\n");
      if (text.trim().length < 40) throw new Error("There is not enough text to review. Add more text or another file.");
      const cut = text.length > MAX_CHARS;
      if (cut) text = text.slice(0, MAX_CHARS);

      setStep("Cross-referencing claims");
      const first = {
        role: "user",
        content: `Document: ${file ? file.name : "Pasted text"}${cut ? " (cut to the first 60,000 characters)" : ""}\n\n${text}`,
      };
      const reply = textOf(await ai.chat([first], { system: SYSTEM }));
      if (!reply.trim()) throw new Error("The review came back empty. Try again.");
      setReport(reply);
      setBase([first, { role: "assistant", content: reply }]);
      setState("done");
    } catch (e) {
      setErr(e?.message || "The review could not be completed.");
      setState("failed");
    }
  };

  const reset = () => {
    setFile(null);
    setPasted("");
    setReport("");
    setBase([]);
    setErr("");
    setState("empty");
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(report);
      toast.success("Report copied");
    } catch {
      toast.error("Could not copy");
    }
  };

  const small =
    "inline-flex min-h-[44px] items-center justify-center rounded-[4px] border border-ink/25 bg-bg px-4 text-[15px] font-medium transition-[color,border-color,box-shadow] duration-150 hover:border-primary hover:text-primary hover:shadow-[inset_3px_0_0_#0F6B4F] active:scale-[0.98]";

  return (
    <section id="audit" className="page-wrap scroll-mt-24 py-6">
      <div className="rounded-[4px] border border-ink/25 p-5 md:p-8 lg:mx-auto lg:w-[83.333%]">
        <h2 className="section-title text-[28px] md:text-[34px]">Audit docket free</h2>
        <div className="mt-6 grid gap-6 md:grid-cols-2">
          <div className="flex flex-col gap-4">
            <button
              type="button"
              onClick={() => input.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                pick(e.dataTransfer.files?.[0]);
              }}
              className="flex h-[220px] w-full flex-col items-center justify-center rounded-[4px] border border-dashed border-primary/60 bg-surface/60 px-6 text-center transition-colors hover:bg-surface"
            >
              <FileUp className="h-10 w-10 text-primary" strokeWidth={1.5} aria-hidden />
              <span className="mt-4 max-w-[16rem] break-words text-[20px] font-medium leading-[1.2] tracking-[-0.02em]">
                {file ? file.name : "Tap to upload docket, minute order, or PDF"}
              </span>
              <span className="mt-2 text-[15px] text-muted">PDF, DOCX, TXT</span>
            </button>
            <input
              ref={input}
              type="file"
              accept=".pdf,.docx,.txt"
              className="sr-only"
              aria-label="Upload a docket file"
              onChange={(e) => {
                pick(e.target.files?.[0]);
                e.target.value = "";
              }}
            />
            <div>
              <label htmlFor="audit-paste" className="block text-[15px] font-medium">
                Or paste the text <span className="font-normal text-muted">(optional)</span>
              </label>
              <textarea
                id="audit-paste"
                rows={4}
                value={pasted}
                onChange={(e) => {
                  setPasted(e.target.value);
                  if (state === "empty" || state === "failed") setState(e.target.value.trim() || file ? "ready" : "empty");
                }}
                className="mt-2 block w-full rounded-[4px] border border-ink/20 bg-bg px-4 py-3 text-[16px] leading-[1.5] focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
            </div>
            <button type="button" onClick={run} disabled={state === "loading"} className={cn(btnPrimary, "w-full disabled:opacity-70")}>
              {state === "loading" ? "Auditing..." : "Audit"}
            </button>
          </div>

          <div
            className="relative flex min-h-[300px] flex-col items-center justify-center rounded-[4px] border border-line bg-surface/50 p-6 text-center md:min-h-[364px]"
            aria-live="polite"
          >
            {(state === "empty" || state === "ready") && (
              <>
                <FileText className="h-12 w-12 text-muted" strokeWidth={1.5} aria-hidden />
                <p className="mt-4 text-[22px] font-medium leading-[1.2] tracking-[-0.02em]">
                  {state === "ready" ? "Ready to audit." : "No document has been audited yet."}
                </p>
                <p className="mt-2 text-[16px] text-muted">
                  {state === "ready" ? "Press Audit to start." : "Upload a supported file or paste text to begin."}
                </p>
              </>
            )}
            {state === "loading" && (
              <div className="w-full max-w-xs" role="status">
                <p className="text-[22px] font-medium tracking-[-0.02em]">{step}</p>
                <p className="mt-2 text-[16px] text-muted">This can take up to a minute.</p>
                <div className="mt-5 h-[3px] overflow-hidden bg-line">
                  <div className="h-full w-1/3 animate-pulse bg-primary motion-reduce:animate-none" />
                </div>
              </div>
            )}
            {state === "failed" && (
              <>
                <span className="h-3 w-3 rounded-full bg-accent" aria-hidden />
                <p className="mt-4 text-[22px] font-medium tracking-[-0.02em]">This audit did not finish</p>
                <p className="mt-2 text-[16px] text-muted">{err || "Try again or send a message."}</p>
                <div className="mt-4 flex flex-wrap justify-center gap-3">
                  {hasInput && (
                    <button type="button" onClick={run} className={small}>
                      Try again
                    </button>
                  )}
                  <Link to={contactHref("general")} className={small}>
                    Send a message
                  </Link>
                </div>
              </>
            )}
            {state === "done" && (
              <div className="w-full">
                <span className="inline-flex items-center gap-2 text-[13px] font-medium text-primary">
                  <span className="h-2 w-2 rounded-full bg-primary" aria-hidden /> Audit complete
                </span>
                <p className="mt-3 text-[22px] font-medium leading-[1.2] tracking-[-0.02em]">Your report is below.</p>
                <div className="mt-5 grid grid-cols-2 gap-3">
                  <button type="button" onClick={copy} className={small}>
                    Copy report
                  </button>
                  <Link to={contactHref("general")} className={small}>
                    Send follow-up
                  </Link>
                  <a href={EXTERNAL.aiCounsel} target="_blank" rel="noreferrer" className={small}>
                    Send to AI Counsel
                  </a>
                  <button type="button" onClick={reset} className={small}>
                    New audit
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {state === "done" && (
          <div className="mt-8 border-t border-line pt-6">
            <Markdown text={report} />
            <AuditChat base={base} />
          </div>
        )}

        <p className="mt-6 text-[14px] text-muted">
          Your text is read in your browser, then sent to an AI service to write the review. Leave out anything you do not want
          shared. {NOTICE}
        </p>
      </div>
    </section>
  );
}
