import { Reveal } from "@wron/kit";

export default function Intro() {
  return (
    <section className="page-wrap pb-10 pt-12 md:pb-14 md:pt-16">
      <Reveal y={12}>
        <div className="grid-12 items-start gap-y-5">
          <div className="flex flex-wrap items-center gap-3 lg:col-span-5">
            <h1 className="inner-title">Truth Engine</h1>
            <span className="status-text inline-flex items-center gap-2 rounded-[4px] bg-surface px-2.5 py-1.5">
              <span className="h-2 w-2 rounded-full bg-primary" aria-hidden />
              <span className="font-medium text-primary">Live</span>
            </span>
          </div>
          <div className="lg:col-span-7">
            <p className="text-[clamp(22px,2.2vw,32px)] font-medium leading-[1.2] tracking-[-0.02em]">
              A systemic review engine for pro per empowerment.
            </p>
            <p className="mt-4 text-[18px] leading-[1.55] text-muted">
              It makes reasoning visible, testable and editable by experts.
            </p>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
