import { Reveal } from "@wron/kit";

const ROWS = [
  { verb: "Pull", body: "Pulls from real sources.", role: "A research assistant", steps: ["Source", "Claim"] },
  { verb: "Test", body: "Cross-references claims and identifies contradictions.", role: "A fact shield", steps: ["Claim", "Conflict"] },
  { verb: "Return", body: "Gives layered, confidence-rated answers backed by receipts.", role: "A signal relay", steps: ["Review", "Answer"] },
];

function Diagram({ steps, conflict }) {
  return (
    <div className="flex items-center gap-2" aria-hidden>
      <span className="h-3 w-3 rounded-full bg-primary" />
      <span className="h-px w-8 bg-ink/30" />
      <span className={conflict ? "h-3 w-3 rounded-full bg-accent" : "h-3 w-3 rounded-full border-2 border-primary"} />
      <span className="ml-2 text-[13px] text-muted">{steps.join(" to ")}</span>
    </div>
  );
}

export default function EngineRows() {
  return (
    <section className="page-wrap mt-10 md:mt-16" aria-labelledby="engine-does">
      <h2 id="engine-does" className="sr-only">What the engine does</h2>
      <div className="border-t border-line">
        {ROWS.map((r, i) => (
          <Reveal key={r.verb} delay={i * 0.07} y={12}>
            <div className="grid gap-4 border-b border-line py-8 transition-shadow duration-150 hover:shadow-[inset_3px_0_0_#0F6B4F] md:grid-cols-12 md:items-center md:gap-6 md:py-10 md:pl-2">
              <p className="text-[clamp(40px,4.2vw,64px)] font-semibold leading-none tracking-[-0.035em] md:col-span-4">{r.verb}</p>
              <p className="text-[clamp(18px,1.6vw,22px)] leading-[1.35] text-muted md:col-span-4">{r.body}</p>
              <div className="md:col-span-4 md:border-l md:border-line md:pl-6">
                <p className="text-[18px] font-medium">{r.role}</p>
                <div className="mt-2">
                  <Diagram steps={r.steps} conflict={r.verb === "Test"} />
                </div>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
