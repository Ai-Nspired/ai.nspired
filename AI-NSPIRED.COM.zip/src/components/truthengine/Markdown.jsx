import { cn } from "@wron/kit";

function inline(text) {
  return text.split(/(\*\*[^*]+\*\*)/g).map((p, i) =>
    p.startsWith("**") && p.endsWith("**") ? (
      <strong key={i} className="font-semibold text-ink">
        {p.slice(2, -2)}
      </strong>
    ) : (
      p
    )
  );
}

/** A small, safe markdown renderer: headings, bullets, numbered lines, bold, paragraphs. */
export default function Markdown({ text, className }) {
  const lines = String(text || "").split("\n");
  const blocks = [];
  let list = null;
  const flush = () => {
    if (list) {
      blocks.push(list);
      list = null;
    }
  };
  lines.forEach((raw, i) => {
    const line = raw.trimEnd();
    const h = line.match(/^(#{1,4})\s+(.*)$/);
    const li = line.match(/^\s*(?:[-*•]|\d+[.)])\s+(.*)$/);
    if (!line.trim()) return flush();
    if (h) {
      flush();
      const title = h[2].replace(/\*\*/g, "");
      const flagged = /conflict|unresolved|contradict/i.test(title);
      blocks.push({
        type: "h",
        key: i,
        title,
        flagged,
      });
    } else if (li) {
      if (!list || list.type !== "ul") {
        flush();
        list = { type: "ul", key: i, items: [] };
      }
      list.items.push(li[1]);
    } else {
      flush();
      blocks.push({ type: "p", key: i, text: line });
    }
  });
  flush();

  return (
    <div className={cn("space-y-3 text-[16px] leading-[1.55] text-muted", className)}>
      {blocks.map((b) => {
        if (b.type === "h")
          return (
            <h3
              key={b.key}
              className={cn(
                "pt-4 text-[20px] font-semibold leading-tight tracking-[-0.02em] text-ink first:pt-0",
                b.flagged && "w-fit rounded-[4px] bg-[#F6DFA0] px-2 py-1"
              )}
            >
              {b.title}
            </h3>
          );
        if (b.type === "ul")
          return (
            <ul key={b.key} className="space-y-2 border-t border-line">
              {b.items.map((it, j) => (
                <li key={j} className="border-b border-line py-2 pl-3 transition-shadow hover:shadow-[inset_3px_0_0_#0F6B4F]">
                  {inline(it)}
                </li>
              ))}
            </ul>
          );
        return <p key={b.key}>{inline(b.text)}</p>;
      })}
    </div>
  );
}
