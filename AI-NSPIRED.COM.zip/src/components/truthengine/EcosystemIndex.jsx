import { ArrowUpRight } from "lucide-react";
import { ECOSYSTEM_INDEX } from "../../data/site";

export default function EcosystemIndex() {
  return (
    <section className="page-wrap py-14 md:py-20">
      <h2 className="section-title">The ecosystem</h2>
      <ul className="mt-8 border-t border-line">
        {ECOSYSTEM_INDEX.map((e) => (
          <li key={e.name} className="border-b border-line">
            <a
              href={e.href}
              target="_blank"
              rel="noreferrer"
              className="group grid min-h-[60px] grid-cols-[1fr_auto] items-center gap-x-6 gap-y-1 px-3 py-4 transition-colors duration-150 hover:bg-surface hover:shadow-[inset_3px_0_0_#0F6B4F] md:grid-cols-[1fr_1.4fr_auto]"
            >
              <span className="text-[22px] font-medium tracking-[-0.02em]">{e.name}</span>
              <ArrowUpRight className="row-span-2 h-5 w-5 text-primary transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5 md:order-3 md:row-span-1" aria-hidden />
              <span className="text-[16px] text-muted">{e.body}</span>
            </a>
          </li>
        ))}
      </ul>
    </section>
  );
}
