import { useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import { FileText, Link2, TriangleAlert, User, CircleHelp } from "lucide-react";
import { cn } from "@wron/kit";

export const LEDGER_ROWS = [
  {
    id: "source",
    icon: FileText,
    title: "Source",
    line: "Verified source material and citations",
    explain: "Every answer starts from material you can open and check.",
    state: "Documented",
    tone: "neutral",
  },
  {
    id: "claim",
    icon: Link2,
    title: "Claim",
    line: "Extracted claim and key assertions",
    explain: "Each claim is pulled out on its own so it can be tested.",
    state: "Identified",
    tone: "neutral",
  },
  {
    id: "conflict",
    icon: TriangleAlert,
    title: "Conflict",
    line: "Contradictory information detected",
    explain: "Where sources disagree, the conflict is shown, not hidden.",
    state: "Requires review",
    tone: "amber",
  },
  {
    id: "review",
    icon: User,
    title: "Expert review",
    line: "Human expert analysis and validation",
    explain: "A human expert can challenge and edit the reasoning.",
    state: "Human accountable",
    tone: "green",
  },
  {
    id: "next",
    icon: CircleHelp,
    title: "Next question",
    line: "Open questions and areas for further research",
    explain: "What is still unknown becomes the next thing to ask.",
    state: "Queued",
    tone: "neutral",
  },
];

const EASE = [0.16, 1, 0.3, 1];

/**
 * The signature evidence ledger: five rows joined by a thin vertical rule.
 * HTML only. Rows fade up 12px in a 70ms sequence; the rule fills top to bottom.
 * Hover or focus a row to swap its sub-line for a plain explanation (no layout shift).
 */
export default function EvidenceLedger({ title = "Evidence Ledger", rows = LEDGER_ROWS, className }) {
  const reduce = useReducedMotion();
  const [active, setActive] = useState(null);
  const total = rows.length;

  return (
    <div className={cn("ledger rounded-[10px] border border-line bg-bg p-3 sm:p-4", className)}>
      <div className="rounded-[6px] border border-line bg-bg">
        <p className="border-b border-line px-4 py-3 text-[18px] font-semibold tracking-[-0.01em] text-ink sm:px-5 sm:text-[20px]">
          {title}
        </p>
        <div className="relative px-2 py-2 sm:px-3">
          {/* connecting rule */}
          <div className="pointer-events-none absolute bottom-10 left-[22px] top-10 w-px bg-line sm:left-[27px]" aria-hidden>
            <motion.div
              className="h-full w-full origin-top bg-ink"
              initial={reduce ? false : { scaleY: 0 }}
              animate={{ scaleY: 1 }}
              transition={{ duration: reduce ? 0 : 0.4 + total * 0.07, ease: EASE, delay: reduce ? 0 : 0.1 }}
            />
          </div>
          <ol className="relative space-y-1.5">
            {rows.map((r, i) => {
              const Icon = r.icon;
              const on = active === r.id;
              return (
                <motion.li
                  key={r.id}
                  initial={reduce ? false : { opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: reduce ? 0 : 0.4, ease: EASE, delay: reduce ? 0 : 0.1 + i * 0.07 }}
                  className="flex items-stretch gap-2 sm:gap-3"
                >
                  <span className="relative flex w-6 shrink-0 items-center justify-center sm:w-8" aria-hidden>
                    <span className="h-2 w-2 rounded-full bg-ink" />
                  </span>
                  <div
                    tabIndex={0}
                    onMouseEnter={() => setActive(r.id)}
                    onMouseLeave={() => setActive(null)}
                    onFocus={() => setActive(r.id)}
                    onBlur={() => setActive(null)}
                    aria-label={`${r.title}: ${r.state}. ${r.explain}`}
                    className={cn(
                      "grid min-w-0 flex-1 grid-cols-1 overflow-hidden rounded-[4px] border transition-[border-color,box-shadow] duration-150 sm:grid-cols-[1fr_minmax(9.5rem,32%)]",
                      r.tone === "amber" ? "border-accent/60 bg-[#F6DFA0]" : "border-line bg-surface/50",
                      on && "shadow-[inset_3px_0_0_#0F6B4F] border-primary/40"
                    )}
                  >
                    <div className="flex min-w-0 items-center gap-3 px-3 py-3 sm:px-4">
                      <Icon className="h-6 w-6 shrink-0 text-ink" strokeWidth={1.5} aria-hidden />
                      <div className="min-w-0">
                        <p className="text-[16px] font-medium leading-tight text-ink">{r.title}</p>
                        <p className="mt-1 text-[14px] leading-snug text-ink/75">{on ? r.explain : r.line}</p>
                      </div>
                    </div>
                    <div
                      className={cn(
                        "flex items-center px-3 py-2 text-[14px] font-medium sm:px-4 sm:py-3",
                        r.tone === "amber" && "bg-[#F2C76A] text-ink",
                        r.tone === "green" && "bg-primary text-primary-ink",
                        r.tone === "neutral" && "border-t border-line bg-surface text-ink sm:border-l sm:border-t-0"
                      )}
                    >
                      {r.state}
                    </div>
                  </div>
                </motion.li>
              );
            })}
          </ol>
        </div>
      </div>
    </div>
  );
}
