import { useEffect, useState } from "react";
import { useSearchParams } from "react-router";
import { Page, storage } from "@wron/kit";
import { TOPICS } from "../data/site";
import ContactForm from "../components/contact/ContactForm";
import TopicGuide from "../components/contact/TopicGuide";

const HERO_IMG = "";

export default function Contact() {
  const [params] = useSearchParams();
  const [topic, setTopic] = useState("general");

  useEffect(() => {
    const q = params.get("topic");
    const saved = storage.get("contact-topic");
    const pick = [q, saved].find((t) => t && TOPICS.some((x) => x.id === t));
    if (pick) setTopic(pick);
  }, [params]);

  const choose = (id) => {
    setTopic(id);
    storage.set("contact-topic", id);
  };

  return (
    <Page
      title="Contact"
      description="Send a message to the right AI-NSPIRED inbox: Feedback & Ideas, Partnerships, Media & Press, Legal or General Ops. Messages are triaged daily."
    >
      <section id="message" className="page-wrap scroll-mt-4 pb-12 pt-10 md:pt-14">
        <div className="grid-12 gap-y-8 lg:gap-y-10">
          <div className="lg:col-span-4">
            <h1 className="inner-title text-[42px] leading-[0.98] text-ink md:text-[52px] lg:text-[clamp(40px,4.2vw,60px)] lg:leading-[1.03]">
              Send the right message to the right inbox.
            </h1>
            <p className="mt-5 text-[18px] leading-[1.55] text-muted">
              Choose a topic first. Messages are triaged daily.
            </p>
            <p className="compact mt-4 text-muted">
              Each topic routes to its own inbox, so the right people see your message first.
            </p>
          </div>
          <div className="lg:col-span-8">
            <ContactForm topic={topic} onTopic={choose} />
          </div>
        </div>
      </section>
      <TopicGuide topic={topic} onTopic={choose} />
      <section className="border-t border-line bg-surface">
        <p className="page-wrap py-6 text-center text-[13px] leading-[1.4] text-muted">
          Not legal advice. For edutainment purposes only. Consult a licensed attorney for legal counsel.
        </p>
      </section>
    </Page>
  );
}
