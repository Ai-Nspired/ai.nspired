import { Page } from "@wron/kit";
import EitlHero from "../components/eitl/EitlHero";
import EitlPath from "../components/eitl/EitlPath";
import EitlQualities from "../components/eitl/EitlQualities";
import EitlRelated from "../components/eitl/EitlRelated";
import EitlContact from "../components/eitl/EitlContact";

export default function Eitl() {
  return (
    <Page
      title="Expert-in-the-Loop (EITL)"
      description="EITL is a governance framework that keeps humans accountable where AI decisions matter. Sources, claims and expert review stay visible."
    >
      <EitlHero />
      <EitlPath />
      <EitlQualities />
      <EitlRelated />
      <EitlContact />
    </Page>
  );
}
