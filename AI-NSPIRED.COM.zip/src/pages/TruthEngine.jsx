import { Page } from "@wron/kit";
import { Reveal } from "@wron/kit";
import { StatusRow } from "../components/ui";
import Intro from "../components/truthengine/Intro";
import AuditWorkspace from "../components/truthengine/AuditWorkspace";
import EngineRows from "../components/truthengine/EngineRows";
import FounderSupport from "../components/truthengine/FounderSupport";
import EcosystemIndex from "../components/truthengine/EcosystemIndex";

export default function TruthEngine() {
  return (
    <Page
      title="Truth Engine"
      description="The Truth Engine is a systemic review engine for pro per empowerment. Upload a docket, minute order or PDF and get a free audit. Not legal advice."
    >
      <Intro />
      <AuditWorkspace />
      <EngineRows />
      <FounderSupport />
      <EcosystemIndex />
    </Page>
  );
}
