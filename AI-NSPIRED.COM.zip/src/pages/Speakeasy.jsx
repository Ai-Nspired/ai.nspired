import { useState } from "react";
import { Link } from "react-router";
import { ArrowRight, ArrowUpRight, Check } from "lucide-react";
import { HERO_IMG } from "../components/home/images";
import { Page, Reveal, Img, useForm, SpamTrap, scrollToSection, cn } from "@wron/kit";
import { btnPrimary, Field } from "../components/ui";
import { EXTERNAL } from "../data/site";


const INDEX = [
  { n: "01", t: "Private" },
  { n: "02", t: "Vetted" },
  { n: "03", t: "Built for people building real systems." },
];

const TOPICS = [
  { id: "Partnerships", label: "Partnerships" },
  { id: "General Ops", label: "General Ops" },
];

function RequestForm() {
  const form = useForm("speakeasy-request");
  const [topic, setTopic] = useState("Partnerships");

  if (form.sent)
    return (
      <div role="status" className="border-y border-line py-8">
        <div className="flex items-start gap-4">
          <span className="mt-1 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-ink">
            <Check className="h-4 w-4" />
          </span>
          <div>
            <p className="text-[20px] font-semibold text-primary">Message received.</p>
            <p className="mt-1 text-muted">Your request has been routed to the selected inbox.</p>
          </div>
        </div>
      </div>
    );

  return (
    <form onSubmit={form.onSubmit} className="grid grid-cols-1 gap-8">
      <SpamTrap />
      <input type="hidden" name="inbox" value={topic} />
      <Field inputClassName="h-14" label="Name" name="name" required placeholder="Your name" autoComplete="name" />
      <Field inputClassName="h-14" label="Email" name="email" type="email" required placeholder="you@domain.com" autoComplete="email" />
      <Field inputClassName="min-h-[150px]" label="What are you building?" name="building" textarea rows={4} required placeholder="Describe your work, project or system..." />
      <Field inputClassName="min-h-[150px]" label="Why are you interested in the Speakeasy?" name="interest" textarea rows={4} required placeholder="Tell us what you're looking for and what you hope to get from this network..." />
      <fieldset>
        <legend className="text-[15px] font-medium text-ink">What topic is this request about?</legend>
        <div className="mt-3 grid grid-cols-2 gap-3">
          {TOPICS.map((t) => (
            <label
              key={t.id}
              className={cn(
                "flex min-h-[52px] cursor-pointer items-center gap-3 rounded-[4px] border px-4 transition-colors hover:border-primary",
                topic === t.id ? "border-primary bg-surface" : "border-ink/20"
              )}
            >
              <input type="radio" name="topic_choice" value={t.id} checked={topic === t.id} onChange={() => setTopic(t.id)} className="h-4 w-4 accent-[#0F6B4F]" />
              <span className="text-[16px]">{t.label}</span>
            </label>
          ))}
        </div>
      </fieldset>
      <div>
        <button type="submit" disabled={form.sending} className={cn(btnPrimary, "w-full disabled:opacity-60 sm:w-auto")}>
          {form.sending ? "Sending..." : "Send request"}
        </button>
        {form.error && <p role="alert" className="mt-3 text-[15px] text-ink">{String(form.error)} Your text is still here. Try again.</p>}
      </div>
    </form>
  );
}

const LINKS = [
  { name: "Truth Engine", body: "The original methodology", to: "/truth-engine" },
  { name: "EITL", body: "Human accountability for AI decisions", to: "/eitl" },
  { name: "Visit Speakeasy", body: "ai-n.org", href: EXTERNAL.speakeasy },
];

export default function Speakeasy() {
  return (
    <Page
      title="The Speakeasy"
      description="A private, vetted network for people building real systems, not hype. Request access and your message is routed to the right inbox."
    >
      <section className="page-wrap grid items-center gap-10 py-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16 lg:py-20">
        <div>
          <Reveal>
            <h1 className="inner-title leading-none lg:text-[68px]">The Speakeasy</h1>
            <p className="mt-6 max-w-xl text-[clamp(22px,2vw,28px)] leading-[1.3] text-muted">
              A private, vetted network for people building real systems, not hype.
            </p>
            <button type="button" onClick={() => scrollToSection("request")} className={cn(btnPrimary, "mt-8 w-full sm:w-auto sm:min-w-[230px]")}>
              Request access
            </button>
          </Reveal>
        </div>
        <div className="aspect-[4/3] w-full overflow-hidden rounded-[4px] lg:aspect-auto lg:h-[600px]">
          <Img
            src={HERO_IMG}
            alt="A person typing on a laptop at a quiet desk with a notebook and pen"
            priority
            className="h-full w-full"
            imgClassName="h-full w-full object-cover object-center"
            sizes="(min-width:1024px) 55vw, 100vw"
          />
        </div>
      </section>

      <section className="bg-primary text-primary-ink">
        <div className="page-wrap grid gap-10 py-14 lg:grid-cols-12 lg:py-20">
          <Reveal className="lg:col-span-8">
            <h2 className="section-title max-w-[16ch] text-[clamp(36px,4.4vw,64px)]">Expert peer review belongs close to the work.</h2>
          </Reveal>
          <dl className="space-y-5 border-t border-primary-ink/30 pt-6 lg:col-span-4 lg:border-l lg:border-t-0 lg:pl-8 lg:pt-0">
            <dt className="text-[16px] font-medium">The Speakeasy</dt>
            {INDEX.map((i) => (
              <dd key={i.n} className="flex gap-5 text-[20px]">
                <span className="tnum">{i.n}</span>
                <span>{i.t}</span>
              </dd>
            ))}
          </dl>
        </div>
      </section>

      <section id="request" className="page-wrap py-14 lg:py-20">
        <div className="mx-auto max-w-[1280px]">
          <h2 className="section-title text-[clamp(36px,4vw,56px)]">Request access</h2>
          <div className="mt-8">
            <RequestForm />
          </div>
        </div>
      </section>

      <section className="page-wrap pb-16">
        <ul className="grid grid-cols-1 items-stretch border-t border-line md:grid-cols-3 md:divide-x md:divide-line">
          {LINKS.map((l) => {
            const inner = (
              <>
                <span>
                  <span className="block text-[20px] font-medium text-primary">{l.name}</span>
                  <span className="mt-1 block text-[15px] text-muted">{l.body}</span>
                </span>
                {l.href ? (
                  <ArrowUpRight className="mt-1 h-5 w-5 shrink-0 text-primary transition-transform group-hover:translate-x-1" aria-hidden />
                ) : (
                  <ArrowRight className="mt-1 h-5 w-5 shrink-0 text-primary transition-transform group-hover:translate-x-1" aria-hidden />
                )}
              </>
            );
            const cls = "group flex h-full min-h-[104px] items-start justify-between gap-4 px-0 py-6 hover:shadow-[inset_3px_0_0_#0F6B4F] md:px-6";
            return (
              <li key={l.name} className="h-full border-b border-line">
                {l.href ? (
                  <a href={l.href} target="_blank" rel="noreferrer" className={cls}>{inner}</a>
                ) : (
                  <Link to={l.to} className={cls}>{inner}</Link>
                )}
              </li>
            );
          })}
        </ul>
      </section>
    </Page>
  );
}
