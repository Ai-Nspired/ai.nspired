import { Page } from "@wron/kit";
import Hero from "../components/home/Hero";
import RouteBand from "../components/home/RouteBand";
import Ecosystem from "../components/home/Ecosystem";
import Method from "../components/home/Method";
import Principles from "../components/home/Principles";
import Closing from "../components/home/Closing";
import { HERO_IMG } from "../components/home/images";

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "AI-NSPIRED.COM",
  url: "https://ai-nspired.com/",
  description:
    "Human-guided AI systems for founders and operators facing legal risk. Educational and advisory systems. Not legal representation.",
};

export default function Home() {
  return (
    <Page
      title="Human-guided AI systems for legal risk"
      description="Human-guided AI systems for founders and operators facing legal risk. Truth Engine, EITL governance and the right inbox for your message."
      image={HERO_IMG}
      jsonLd={jsonLd}
    >
      <Hero />
      <RouteBand />
      <Ecosystem />
      <Method />
      <Principles />
      <Closing />
    </Page>
  );
}
