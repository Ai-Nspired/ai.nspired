import { Page } from "@wron/kit";
import { Button, TextLink } from "../components/ui";

export default function NotFound() {
  return (
    <Page title="Page not found" description="This page is not part of AI-NSPIRED.COM. Go back home or send a message to the right inbox." noindex>
      <section className="page-wrap py-24 md:py-32">
        <p className="status-text inline-flex items-center gap-2 rounded-[4px] bg-[#F6DFA0] px-2.5 py-1.5 text-ink">
          <span className="h-2 w-2 rounded-full bg-ink" aria-hidden /> Source not found
        </p>
        <h1 className="inner-title mt-6 max-w-[16ch] text-ink">There is no page at this address.</h1>
        <p className="mt-5 max-w-xl text-[18px] text-muted">
          The link may be old or mistyped. Start again from the home page, or tell us what you were looking for.
        </p>
        <div className="mt-8 flex flex-wrap items-center gap-6">
          <Button to="/">Go to the home page</Button>
          <TextLink to="/contact#message" arrow>
            Send a message
          </TextLink>
        </div>
      </section>
    </Page>
  );
}
