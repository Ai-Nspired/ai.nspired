import { Page, Reveal } from "@wron/kit";
import { Link } from "react-router";
import { ArrowRight } from "lucide-react";
import { NOTICE, NOT_REPRESENTATION, PRINCIPLES, contactHref } from "../data/site";
import { btnPrimary } from "../components/ui";

const TOC = [
  { id: "intro", label: "Introduction" },
  { id: "use-notice", label: "Use notice" },
  { id: "privacy", label: "Privacy principles" },
  { id: "legal-contact", label: "Legal contact" },
];

export default function TermsPrivacy() {
  return (
    <Page
      title="Terms & Privacy"
      description="Terms and privacy principles for AI-Nspired. Educational and advisory systems, not legal representation. Zero-knowledge, you own your data."
    >
      <div className="page-wrap grid-12 pb-24 pt-14 lg:pt-24">
        <aside className="hidden lg:col-span-2 lg:block">
          <nav aria-label="Contents" className="sticky top-28">
            <p className="text-[15px] font-semibold">Contents</p>
            <ul className="mt-3 border-l border-line">
              {TOC.map((t) => (
                <li key={t.id}>
                  <a
                    href={`#${t.id}`}
                    className="-ml-px block border-l-2 border-transparent py-2 pl-4 text-[15px] text-muted transition-colors hover:border-primary hover:text-primary"
                  >
                    {t.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </aside>

        <div className="lg:col-span-7 lg:col-start-4">
          <Reveal>
            <section id="intro" className="scroll-mt-28 pb-10">
              <h1 className="inner-title text-ink">Terms &amp; Privacy</h1>
              <p className="mt-6 text-[18px] leading-[1.55] text-muted">
                AI-Nspired provides educational and advisory systems. It is not legal representation.
              </p>
            </section>
          </Reveal>

          <section id="use-notice" className="scroll-mt-28 border-t border-line py-10">
            <h2 className="section-title">Use notice</h2>
            <p className="mt-5 text-[18px] leading-[1.55]">{NOTICE}</p>
            <p className="mt-4 text-[18px] leading-[1.55] text-muted">{NOT_REPRESENTATION}</p>
          </section>

          <section id="privacy" className="scroll-mt-28 border-t border-line pt-10">
            <h2 className="section-title">Privacy principles</h2>
            <p className="mt-5 text-[18px] leading-[1.55] text-muted">Zero-knowledge. You own your data. We do not sell your data.</p>
            <ul className="mt-8 border-t border-line">
              {PRINCIPLES.map((p, i) => (
                <li
                  key={p.name}
                  className="grid gap-1 border-b border-line py-5 transition-shadow hover:shadow-[inset_3px_0_0_#0F6B4F] sm:grid-cols-[3rem_10rem_1fr] sm:gap-4 sm:pl-3"
                >
                  <span className="tnum text-[15px] text-muted">{String(i + 1).padStart(2, "0")}</span>
                  <span className="text-[18px] font-semibold">{p.name}</span>
                  <span className="text-[18px] leading-[1.55] text-muted">{p.short}</span>
                </li>
              ))}
            </ul>
          </section>

          <section id="legal-contact" className="scroll-mt-28 pt-14">
            <div className="flex flex-col gap-5 rounded-[4px] border border-ink/20 p-6 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <span className="status-text inline-flex items-center gap-2 rounded-[4px] bg-surface px-2.5 py-1.5">
                  <span className="h-2 w-2 rounded-full bg-primary" aria-hidden />
                  Topic: Legal
                </span>
                <h2 className="mt-3 text-[26px] font-semibold leading-[1.15] tracking-[-0.03em]">
                  Questions about terms or privacy?
                </h2>
              </div>
              <Link to={contactHref("legal")} className={`${btnPrimary} group shrink-0`}>
                Send a legal message
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
              </Link>
            </div>
          </section>
        </div>
      </div>
    </Page>
  );
}
