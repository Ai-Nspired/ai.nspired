import { Page, Reveal } from "@wron/kit";
import { NOT_REPRESENTATION, PRINCIPLES } from "../data/site";
import { TopicRoutes, Button } from "../components/ui";
import { Target, Users, ShieldCheck, FileText, Link2, Search, BarChart3 } from "lucide-react";

const ICONS = [Target, Users, ShieldCheck];

function Eyebrow({ children }) {
  return (
    <p className="flex items-center gap-3 text-[15px] font-medium text-primary">
      <span className="h-px w-8 bg-primary" aria-hidden />
      {children}
    </p>
  );
}

const ROWS = [
  { icon: FileText, name: "Source", body: "Verified materials and citations" },
  { icon: Link2, name: "Claim", body: "Extracted claims and key assertions" },
  { icon: Search, name: "Contradiction", body: "Cross-references and checks" },
  { icon: BarChart3, name: "Confidence", body: "Layered, rated findings" },
];

const ROLES = ["Legal minds", "Code architects", "Builders"];

export default function About() {
  return (
    <Page
      title="About"
      description="AI-Nspired builds human-guided AI systems that turn expertise into auditable, repeatable clarity. Educational and advisory. Not legal representation."
    >
      <section className="page-wrap pb-16 pt-14 md:pb-24 md:pt-20">
        <div className="grid-12 gap-y-8">
          <Reveal className="lg:col-span-7">
            <Eyebrow>About</Eyebrow>
            <h1 className="inner-title mt-5">Democratizing access to justice.</h1>
          </Reveal>
          <Reveal delay={0.1} className="lg:col-span-5 lg:border-l lg:border-line lg:pl-10">
            <p className="max-w-[34rem] text-[18px] leading-[1.55] text-muted">
              AI-Nspired builds human-guided AI systems that turn expertise into auditable, repeatable clarity.
            </p>
            <p className="mt-5 text-[16px] text-muted">{NOT_REPRESENTATION}</p>
          </Reveal>
        </div>
      </section>

      <section className="bg-surface py-14 md:py-20">
        <div className="page-wrap grid-12 items-center gap-y-10">
          <Reveal className="lg:col-span-5 lg:pr-8">
            <Eyebrow>The brainchild</Eyebrow>
            <h2 className="section-title mt-5">TruthEngine is a signal processor and contradiction killer.</h2>
            <p className="mt-6 text-[18px] leading-[1.55] text-muted">
              It pulls from real sources, cross-references claims and returns layered, confidence-rated answers backed by receipts.
            </p>
            <p className="mt-4 text-[18px] leading-[1.55] text-muted">
              It is a research assistant, a fact shield and a signal relay.
            </p>
          </Reveal>
          <div className="lg:col-span-6 lg:col-start-7">
            <div className="grid items-center gap-6 rounded-[10px] border border-line bg-bg p-5 sm:grid-cols-[1fr_auto_1fr]">
              <ul className="w-full space-y-2">
                {ROWS.map((r) => (
                  <li key={r.name} className="flex w-full items-center gap-3 rounded-[6px] border border-line p-3 transition-shadow hover:shadow-[inset_3px_0_0_#0F6B4F]">
                    <r.icon className="h-5 w-5 shrink-0 text-primary" aria-hidden />
                    <span>
                      <span className="block text-[15px] font-medium">{r.name}</span>
                      <span className="block text-[14px] leading-[1.4] text-muted">{r.body}</span>
                    </span>
                  </li>
                ))}
              </ul>
              <div className="relative rounded-[8px] bg-primary p-5 text-center text-primary-ink sm:max-w-[11rem]">
                <span aria-hidden className="absolute -left-6 top-1/2 hidden h-px w-6 bg-primary sm:block" />
                <span aria-hidden className="absolute -right-6 top-1/2 hidden h-px w-6 bg-primary sm:block" />
                <p className="text-[18px] font-semibold">TruthEngine</p>
                <p className="mt-1 text-[14px] opacity-90">Signal processor and contradiction killer</p>
              </div>
              <div className="w-full rounded-[8px] border border-line bg-surface p-5 text-center">
                <FileText className="mx-auto h-6 w-6 text-primary" aria-hidden />
                <p className="mt-2 text-[18px] font-semibold">Receipts</p>
                <p className="mt-1 text-[14px] text-muted">Auditable sources, citations and explanations</p>
              </div>
            </div>
            <p className="mt-4 grid text-[15px] font-medium text-primary sm:grid-cols-[1fr_auto_1fr] sm:gap-6 sm:px-5">
              <span>Source</span>
              <span className="sm:max-w-[11rem] sm:text-center">Contradiction</span>
              <span className="sm:text-center">Receipt</span>
            </p>
          </div>
        </div>
      </section>

      <section className="page-wrap py-14 md:py-20">
        <div className="flex flex-col gap-3 md:flex-row md:items-baseline md:justify-between">
          <Eyebrow>Who we are</Eyebrow>
          <p className="text-[18px] text-muted">20+ years inside real legal systems.</p>
        </div>
        <div className="mt-8 grid min-h-0 gap-0 divide-y divide-line border-y border-line md:grid-cols-3 md:divide-x md:divide-y-0">
          {ROLES.map((r) => (
            <h2 key={r} className="section-title py-8 md:px-8 md:first:pl-0">
              {r}
            </h2>
          ))}
        </div>
      </section>

      <section aria-label="Philosophy">
        {PRINCIPLES.map((p, i) => {
          const Icon = ICONS[i];
          return (
            <div key={p.name} className={i % 2 === 0 ? "bg-surface" : "bg-bg"}>
              <div className="page-wrap grid items-center gap-6 py-12 md:grid-cols-2 md:py-16">
                <div className="flex items-center gap-5">
                  <Icon className="h-10 w-10 text-primary" aria-hidden />
                  <h2 className="section-title">{p.name}</h2>
                </div>
                <p className="max-w-md text-[22px] leading-[1.3] md:border-l md:border-line md:pl-10">{p.long}</p>
              </div>
            </div>
          );
        })}
      </section>

      <section className="page-wrap py-14 md:py-20">
        <div className="grid-12 gap-y-8">
          <div className="lg:col-span-5">
            <span className="mb-5 block h-px w-12 bg-primary" aria-hidden />
            <h2 className="section-title">Have context that should shape the work?</h2>
            <Button to="/contact#message" className="mt-6">Send a message</Button>
          </div>
          <div className="lg:col-span-7 lg:border-l lg:border-line lg:pl-10">
            <TopicRoutes ids={["feedback", "partnerships", "general"]} />
          </div>
        </div>
      </section>
    </Page>
  );
}
