import { Routes, Route } from "react-router";
import Layout from "./components/Layout";
import Home from "./pages/Home";
import TruthEngine from "./pages/TruthEngine";
import Eitl from "./pages/Eitl";
import Speakeasy from "./pages/Speakeasy";
import About from "./pages/About";
import Contact from "./pages/Contact";
import TermsPrivacy from "./pages/TermsPrivacy";
import NotFound from "./pages/NotFound";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="/truth-engine" element={<TruthEngine />} />
        <Route path="/eitl" element={<Eitl />} />
        <Route path="/speakeasy" element={<Speakeasy />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/terms-privacy" element={<TermsPrivacy />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
