// Shared content for every page. Facts only from the business's own site.

export const SITE_NAME = "AI-NSPIRED.COM";

export const NOTICE =
  "Not legal advice. For edutainment purposes only. Consult a licensed attorney for legal counsel.";

export const NOT_REPRESENTATION = "Educational and advisory systems. Not legal representation.";

export const COPYRIGHT = "© 2026 AI-Nspired Foundation. The Constellation of Integrity.";

export const NAV = [
  { label: "Truth Engine", to: "/truth-engine" },
  { label: "EITL", to: "/eitl" },
  { label: "Speakeasy", to: "/speakeasy" },
  { label: "About", to: "/about" },
  { label: "Contact", to: "/contact" },
];

// The five inboxes from the Contact page.
export const TOPICS = [
  { id: "feedback", label: "Feedback & Ideas", description: "Share product feedback or an idea.", email: "feedback@nspired.cc" },
  { id: "partnerships", label: "Partnerships", description: "Start a partnership conversation.", email: "partnership@nspired.cc" },
  { id: "media", label: "Media & Press", description: "Send a media or press inquiry.", email: "media@nspired.cc" },
  { id: "legal", label: "Legal", description: "Send a legal or policy-related message.", email: "legal@nspired.cc" },
  { id: "general", label: "General Ops", description: "Send an operational or general message.", email: "genops@nspired.cc" },
];

export const topicById = (id) => TOPICS.find((t) => t.id === id) || null;

// Link to the Contact page with an inbox preselected.
export const contactHref = (topicId) => (topicId ? `/contact?topic=${topicId}#message` : "/contact#message");

export const EXTERNAL = {
  truthEngineOriginal: "https://ai-n.org/",
  speakeasy: "https://ai-n.org/",
  aiCounsel: "https://theofficialaicounsel.com/",
  aiUniversity: "https://theofficialaiuniversity.com/",
  foundation: "https://nspired.cc/",
};

// Home page ecosystem map.
export const ECOSYSTEM = [
  {
    id: "truth-engine",
    name: "Truth Engine",
    body: "Makes reasoning visible, testable and editable by experts.",
    to: "/truth-engine",
    role: "Methodology",
  },
  {
    id: "eitl",
    name: "EITL",
    body: "An Expert-in-the-Loop governance framework that keeps humans accountable where AI decisions matter.",
    to: "/eitl",
    role: "Governance",
  },
  {
    id: "ai-counsel",
    name: "The Official AI Counsel",
    body: "Applied legal-risk clarity for founders and operators.",
    href: EXTERNAL.aiCounsel,
    role: "Applied legal-risk clarity",
  },
  {
    id: "ai-university",
    name: "The Official AI University",
    body: "A practical path for human-AI collaboration.",
    href: EXTERNAL.aiUniversity,
    role: "Learning",
  },
  {
    id: "speakeasy",
    name: "The Speakeasy",
    body: "A private, vetted network for people building real systems, not hype.",
    to: "/speakeasy",
    role: "Peer review",
  },
];

// The ecosystem index as the original site lists it (Truth Engine page).
export const ECOSYSTEM_INDEX = [
  { name: "Truth Engine", body: "The original methodology", href: EXTERNAL.truthEngineOriginal },
  { name: "Speakeasy", body: "Expert peer-review enclave", href: EXTERNAL.speakeasy },
  { name: "AI Counsel", body: "Motion and pleading assembly", href: EXTERNAL.aiCounsel },
  { name: "Academy", body: "Litigation mastery curriculum", href: EXTERNAL.aiUniversity },
  { name: "Foundation", body: "Open infrastructure", href: EXTERNAL.foundation },
];

export const PRINCIPLES = [
  { name: "Pragmatic", short: "Clarity that can be used.", long: "Build clarity that can be tested and used." },
  { name: "Personal", short: "Human expertise remains accountable.", long: "Keep human expertise and accountability in the loop." },
  { name: "Private", short: "Zero-knowledge. You own your data. We do not sell your data.", long: "Zero-knowledge. You own your data. We do not sell your data." },
];

export const FOOTER_LINKS = {
  systems: [
    { label: "Truth Engine", to: "/truth-engine" },
    { label: "EITL", to: "/eitl" },
    { label: "Speakeasy", to: "/speakeasy" },
    { label: "About", to: "/about" },
    { label: "Contact", to: "/contact" },
  ],
  ecosystem: [
    { label: "Truth Engine", href: EXTERNAL.truthEngineOriginal },
    { label: "Speakeasy", href: EXTERNAL.speakeasy },
    { label: "AI Counsel", href: EXTERNAL.aiCounsel },
    { label: "AI University", href: EXTERNAL.aiUniversity },
    { label: "NSPIRED.CC", href: EXTERNAL.foundation },
  ],
};
